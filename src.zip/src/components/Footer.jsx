import { Link } from "react-router-dom";
import { Leaf } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t mt-24 pb-16 pt-16 bg-cream" style={{ borderColor: "rgba(44,64,46,0.08)" }}>
      <div className="max-w-7xl mx-auto px-6 sm:px-8 grid grid-cols-2 md:grid-cols-5 gap-10">
        <div className="col-span-2">
          <div className="flex items-center gap-2.5 mb-4">
            <span className="w-9 h-9 rounded-full bg-sage flex items-center justify-center">
              <Leaf className="w-4 h-4 text-cream" />
            </span>
            <span className="font-serif-display text-2xl text-forest">flourish</span>
          </div>
          <p className="text-sm text-moss max-w-xs leading-relaxed">
            We're not a spy app. We're a wellness coach. Helping families find balance through compassion, not control.
          </p>
        </div>
        <div>
          <div className="label-tiny mb-3">Product</div>
          <ul className="space-y-2 text-sm text-moss">
            <li><Link to="/dashboard" className="hover:text-forest">Dashboard</Link></li>
            <li><Link to="/quests" className="hover:text-forest">Quest Engine</Link></li>
            <li><Link to="/marketplace" className="hover:text-forest">Marketplace</Link></li>
            <li><Link to="/family" className="hover:text-forest">Family</Link></li>
            <li><Link to="/pricing" className="hover:text-forest">Pricing</Link></li>
          </ul>
        </div>
        <div>
          <div className="label-tiny mb-3">Philosophy</div>
          <ul className="space-y-2 text-sm text-moss">
            <li>Compassion over control</li>
            <li>Transparent by design</li>
            <li>Real-world rewards</li>
            <li>Co-created rules</li>
          </ul>
        </div>
        <div>
          <div className="label-tiny mb-3">Contact</div>
          <ul className="space-y-2 text-sm text-moss">
            <li>hello@flourish.app</li>
            <li>India · Worldwide</li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 sm:px-8 mt-12 pt-6 border-t flex flex-col sm:flex-row justify-between gap-3" style={{ borderColor: "rgba(44,64,46,0.08)" }}>
        <p className="text-xs text-moss">© 2026 Flourish — A family wellness studio.</p>
        <p className="text-xs text-moss">Made with care for families finding balance.</p>
      </div>
    </footer>
  );
}
