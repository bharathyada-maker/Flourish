import { Link, useNavigate, useLocation } from "react-router-dom";
import { auth } from "@/lib/api";
import { Leaf, LogOut, User } from "lucide-react";

export default function Nav({ minimal = false }) {
  const nav = useNavigate();
  const loc = useLocation();
  const u = auth.user();

  const onLogout = async () => {
    await auth.logout();
    nav("/");
  };

  const linkCls = (p) =>
    `text-sm transition-colors ${
      loc.pathname.startsWith(p) ? "text-forest font-medium" : "text-moss hover:text-forest"
    }`;

  return (
    <header
      data-testid="top-nav"
      className="sticky top-0 z-40 bg-cream/80 backdrop-blur-md border-b border-forest"
      style={{ borderColor: "rgba(44,64,46,0.08)" }}
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2.5" data-testid="brand-link">
          <span className="w-9 h-9 rounded-full bg-sage flex items-center justify-center">
            <Leaf className="w-4 h-4 text-cream" strokeWidth={2} />
          </span>
          <span className="font-serif-display text-2xl text-forest tracking-tight">flourish</span>
        </Link>

        {!minimal && (
          <nav className="hidden md:flex items-center gap-8">
            <Link to="/dashboard" className={linkCls("/dashboard")} data-testid="nav-dashboard">Dashboard</Link>
            <Link to="/quests" className={linkCls("/quests")} data-testid="nav-quests">Quest Engine</Link>
            <Link to="/marketplace" className={linkCls("/marketplace")} data-testid="nav-marketplace">Marketplace</Link>
            <Link to="/family" className={linkCls("/family")} data-testid="nav-family">Family</Link>
            <Link to="/pricing" className={linkCls("/pricing")} data-testid="nav-pricing">Pricing</Link>
            <Link to="/child" className={linkCls("/child")} data-testid="nav-child-app">Child App</Link>
          </nav>
        )}

        <div className="flex items-center gap-3">
          {u ? (
            <>
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface border" style={{ borderColor: "rgba(44,64,46,0.1)" }}>
                <User className="w-3.5 h-3.5 text-sage" />
                <span className="text-xs text-forest">{u.name}</span>
                {u.tier === "premium" && (
                  <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full bg-sage text-cream">Premium</span>
                )}
              </div>
              <button onClick={onLogout} className="btn-ghost" data-testid="logout-btn">
                <LogOut className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-ghost text-sm" data-testid="nav-login">Sign in</Link>
              <Link to="/register" className="btn-primary text-sm" data-testid="nav-register">Get started</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
