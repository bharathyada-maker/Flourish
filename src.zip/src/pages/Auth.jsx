import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, auth } from "@/lib/api";
import { Leaf, ArrowRight } from "lucide-react";

export default function AuthPage({ mode = "login" }) {
  const nav = useNavigate();
  const isRegister = mode === "register";
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      const url = isRegister ? "/auth/register" : "/auth/login";
      const body = isRegister ? form : { email: form.email, password: form.password };
      const { data } = await api.post(url, body);
      // Backend also sets an httpOnly cookie when CORS permits; we keep the
      // Bearer token + user profile in localStorage as the cross-origin fallback.
      auth.setSession(data.token, data.user);
      if (isRegister) {
        try { await api.post("/seed/demo"); } catch (seedErr) { console.warn("seed/demo skipped:", seedErr); }
      }
      nav("/dashboard");
    } catch (e) {
      console.error("auth failed", e);
      setErr(e?.response?.data?.detail || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-cream grid grid-cols-1 lg:grid-cols-2">
      <div className="hidden lg:block relative overflow-hidden">
        <img
          src="https://images.pexels.com/photos/3536241/pexels-photo-3536241.jpeg?auto=compress&cs=tinysrgb&h=1200&w=900"
          alt=""
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(44,64,46,0.55), rgba(44,64,46,0.2))" }} />
        <div className="absolute inset-0 p-12 flex flex-col justify-between text-cream">
          <Link to="/" className="flex items-center gap-2.5 w-fit">
            <span className="w-9 h-9 rounded-full bg-cream/20 backdrop-blur flex items-center justify-center">
              <Leaf className="w-4 h-4 text-cream" />
            </span>
            <span className="font-serif-display text-2xl">flourish</span>
          </Link>
          <div>
            <p className="font-serif-display text-3xl lg:text-4xl leading-tight max-w-md">
              "We're not measuring my child. We're <em>knowing</em> her."
            </p>
            <p className="text-xs uppercase tracking-[0.3em] mt-4 opacity-70">— Mira, parent of 14yo</p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          <Link to="/" className="flex items-center gap-2 lg:hidden mb-8">
            <span className="w-9 h-9 rounded-full bg-sage flex items-center justify-center">
              <Leaf className="w-4 h-4 text-cream" />
            </span>
            <span className="font-serif-display text-2xl text-forest">flourish</span>
          </Link>

          <div className="label-tiny mb-3">{isRegister ? "Begin your journey" : "Welcome back"}</div>
          <h1 className="font-serif-display text-4xl sm:text-5xl text-forest leading-tight mb-3">
            {isRegister ? "Create your family." : "Sign in."}
          </h1>
          <p className="text-moss mb-8 leading-relaxed">
            {isRegister
              ? "It takes a minute. Then we'll set up your child's wellness space."
              : "Your family's calm corner of the internet."}
          </p>

          <form onSubmit={submit} className="space-y-4">
            {isRegister && (
              <div>
                <label className="label-tiny block mb-2">Your name</label>
                <input
                  className="input-soft"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Mira Kapoor"
                  required
                  data-testid="auth-name"
                />
              </div>
            )}
            <div>
              <label className="label-tiny block mb-2">Email</label>
              <input
                type="email"
                className="input-soft"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="you@home.in"
                required
                data-testid="auth-email"
              />
            </div>
            <div>
              <label className="label-tiny block mb-2">Password</label>
              <input
                type="password"
                className="input-soft"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                placeholder="At least 8 characters"
                required
                minLength={6}
                data-testid="auth-password"
              />
            </div>
            {err && <div className="text-sm text-terra bg-terra/10 rounded-2xl p-3" data-testid="auth-error">{err}</div>}
            <button type="submit" disabled={loading} className="btn-primary w-full mt-2" data-testid="auth-submit">
              {loading ? "..." : isRegister ? "Create account" : "Sign in"} <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <p className="text-sm text-moss mt-8">
            {isRegister ? "Already have an account?" : "New to Flourish?"}{" "}
            <Link to={isRegister ? "/login" : "/register"} className="text-sage-deep underline underline-offset-4" data-testid="auth-toggle-link">
              {isRegister ? "Sign in" : "Create one"}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
