import { Link } from "react-router-dom";
import { Sparkles, ShieldCheck, Heart, Trees, ArrowRight, Quote, Sun, Eye, EyeOff, MessageCircleHeart, Wand2, Star, Check, X, Leaf, Compass } from "lucide-react";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";

const HERO_IMG = "https://images.pexels.com/photos/14061435/pexels-photo-14061435.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=900&w=900";
const FAMILY_COOKING = "https://images.pexels.com/photos/7469438/pexels-photo-7469438.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=700&w=940";
const TEEN_READING = "https://images.pexels.com/photos/18106160/pexels-photo-18106160.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=700&w=940";
const CHILD_NATURE = "https://images.pexels.com/photos/3536241/pexels-photo-3536241.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=700&w=940";

// Friendly avatar svg placeholders
const AVATARS = [
  "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=faces",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=faces",
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-cream text-forest overflow-hidden">
      <Nav />

      {/* ============ HERO ============ */}
      <section className="relative">
        {/* decorative blobs */}
        <div className="blob blob-sage" style={{ top: "-100px", left: "-80px", width: 380, height: 380 }} />
        <div className="blob blob-gold" style={{ top: "200px", right: "-60px", width: 320, height: 320 }} />

        {/* floating SVG leaves */}
        <FloatingLeaf className="absolute top-32 right-1/4 w-10 h-10 text-sage opacity-40 drift" />
        <FloatingLeaf className="absolute top-[60%] left-10 w-8 h-8 text-gold opacity-30 drift" style={{ animationDelay: "2s" }} />

        <div className="max-w-7xl mx-auto px-6 sm:px-8 pt-16 lg:pt-24 pb-24 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-16 items-center relative z-10">
          <div className="lg:col-span-7 fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-sage/10 border border-sage/20 mb-7">
              <span className="dot-sparkle" />
              <span className="text-xs tracking-[0.2em] uppercase text-sage-deep font-semibold">Family Digital Wellness · 2026</span>
            </div>

            <h1 className="font-serif-display text-5xl sm:text-6xl lg:text-7xl xl:text-[88px] leading-[0.95] text-forest mb-7">
              Help your child<br />
              <span className="italic relative inline-block" style={{ color: "#5d7a5f" }}>
                <span className="serif-underline">flourish</span>
              </span> beyond<br />
              the screen.
            </h1>

            <p className="text-lg sm:text-xl text-moss max-w-xl leading-relaxed mb-10">
              Not a spy app. A wellness coach. Flourish gently nudges children toward real-world quests, mindful breaks and family time —
              <span className="text-forest"> through compassion, not control.</span>
            </p>

            <div className="flex flex-wrap items-center gap-4 mb-12">
              <Link to="/register" className="btn-primary" data-testid="hero-get-started">
                Start free <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/child" className="btn-secondary" data-testid="hero-child-app">
                I'm a child / teen
              </Link>
            </div>

            <div className="flex flex-wrap gap-x-10 gap-y-4">
              {[
                ["12,000+", "families calmer this month"],
                ["3×", "more rule follow-through"],
                ["89%", "kids feel respected"],
              ].map(([n, l]) => (
                <div key={l}>
                  <div className="font-serif-display text-3xl text-forest">{n}</div>
                  <div className="text-xs text-moss tracking-wider uppercase mt-1">{l}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Hero visual */}
          <div className="lg:col-span-5 fade-up relative" style={{ animationDelay: "150ms" }}>
            <div className="relative">
              <div className="rounded-[40px] overflow-hidden shadow-2xl aspect-[4/5] relative">
                <img src={HERO_IMG} alt="Family in autumn" className="w-full h-full object-cover" />
                <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 50%, rgba(44,64,46,0.5) 100%)" }} />
                <div className="absolute bottom-6 left-6 right-6 card-glass p-5">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-full bg-sage flex items-center justify-center relative">
                      <Sparkles className="w-4 h-4 text-cream" />
                      <span className="absolute inset-0 rounded-full bg-sage pulse-ring" />
                    </div>
                    <div>
                      <div className="text-xs label-tiny">Bloom · AI Coach</div>
                      <div className="text-[10px] text-moss">just now</div>
                    </div>
                  </div>
                  <p className="text-sm text-forest leading-relaxed">
                    "Hey, you've been gaming for 3h. Your brain's tired — totally normal. Worth 150 XP if you cycle to the park instead?"
                  </p>
                </div>
              </div>

              {/* Floating XP card */}
              <div className="absolute -left-4 sm:-left-10 top-10 card-soft p-4 hidden sm:block float-y" style={{ animationDelay: "0.8s" }}>
                <div className="label-tiny">Today's Wellness</div>
                <div className="font-serif-display text-4xl text-forest mt-1">84</div>
                <div className="text-xs text-sage">↑ 12 from yesterday</div>
              </div>

              {/* Floating badge card */}
              <div className="absolute -right-2 sm:-right-8 bottom-32 card-soft p-3.5 px-5 hidden sm:flex items-center gap-3 float-y" style={{ animationDelay: "1.6s" }}>
                <span className="text-2xl bounce-soft">🚴</span>
                <div>
                  <div className="text-xs text-moss">Quest accepted</div>
                  <div className="text-sm text-forest font-medium">+150 XP</div>
                </div>
              </div>

              {/* Star sparkle */}
              <div className="absolute -top-4 -right-4 hidden sm:block sparkle-anim">
                <Star className="w-8 h-8 text-gold fill-gold" />
              </div>
            </div>
          </div>
        </div>

        {/* Trust strip */}
        <div className="border-y border-forest py-4 bg-surface/40 overflow-hidden" style={{ borderColor: "rgba(44,64,46,0.08)" }}>
          <div className="marquee text-sm text-moss tracking-[0.2em] uppercase font-medium opacity-70">
            {["a", "b"].map((dup) => (
              <div key={`marquee-${dup}`} className="flex items-center gap-12">
                <span>🌿 Featured in The Wellness Edit</span>
                <span>★ Loved by 12,000 families</span>
                <span>🇮🇳 Built for India · the world</span>
                <span>🛡️ Private by design</span>
                <span>💚 No ads, ever</span>
                <span>🧘 Mindful Tech Award 2026</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ PHILOSOPHY (dark band) ============ */}
      <section className="relative bg-forest text-cream py-24 sm:py-32 grain overflow-hidden">
        <div className="blob blob-gold" style={{ top: "-80px", right: "-80px", width: 400, height: 400, opacity: 0.25 }} />
        <div className="blob blob-sage" style={{ bottom: "-100px", left: "-100px", width: 400, height: 400, opacity: 0.3 }} />

        <div className="max-w-5xl mx-auto px-6 sm:px-8 text-center relative z-10">
          <Quote className="w-8 h-8 mx-auto mb-6 opacity-50" />
          <p className="font-serif-display-soft text-3xl sm:text-4xl lg:text-5xl leading-[1.15] mb-8" style={{ color: "#f5f1e8" }}>
            "Children whose parents <em>co-create</em> the rules are <span style={{ color: "#dca750" }} className="serif-underline">three times</span> more likely to follow them — and feel respected doing so."
          </p>
          <p className="text-sm uppercase tracking-[0.3em] opacity-60">— The Flourish Philosophy</p>
        </div>
      </section>

      {/* ============ NEW: vs Spy apps comparison ============ */}
      <section className="relative py-24 sm:py-32 overflow-hidden">
        <div className="blob blob-rose" style={{ top: "100px", right: "-120px", width: 350, height: 350 }} />

        <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
          <div className="max-w-3xl mb-16">
            <div className="label-tiny mb-4">The difference</div>
            <h2 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] mb-6">
              Old apps watch.<br /><em className="text-sage">Flourish nurtures.</em>
            </h2>
            <p className="text-lg text-moss leading-relaxed">
              Most "parental control" apps make children feel surveilled, sneaky, or untrusted. Flourish is built on the opposite belief — that children, given honest tools and gentle nudges, mostly do the right thing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Old way */}
            <div className="card-soft p-8 relative overflow-hidden" data-testid="compare-old">
              <div className="flex items-center gap-3 mb-7">
                <div className="w-12 h-12 rounded-full bg-terra/15 flex items-center justify-center">
                  <EyeOff className="w-5 h-5 text-terra" />
                </div>
                <div>
                  <div className="label-tiny" style={{ color: "#a04030" }}>The old way</div>
                  <div className="font-serif-display text-xl text-forest">Spy & restrict apps</div>
                </div>
              </div>
              <ul className="space-y-3 text-sm text-moss">
                {[
                  "Hidden tracking — child feels watched, not trusted",
                  "Hard locks → workarounds, sneaking, secrets",
                  "Numbers only: minutes, hours, blocks",
                  "Parent vs child conflict",
                  "No support, no coaching, no growth",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-3">
                    <X className="w-4 h-4 text-terra flex-shrink-0 mt-0.5" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Flourish way */}
            <div className="card-soft elevated p-8 relative overflow-hidden gradient-sage-cream" data-testid="compare-flourish">
              <div className="absolute top-4 right-4 sparkle-anim">
                <Sparkles className="w-6 h-6 text-gold" />
              </div>
              <div className="flex items-center gap-3 mb-7">
                <div className="w-12 h-12 rounded-full bg-sage flex items-center justify-center">
                  <Eye className="w-5 h-5 text-cream" />
                </div>
                <div>
                  <div className="label-tiny">The Flourish way</div>
                  <div className="font-serif-display text-xl text-forest">A wellness coach</div>
                </div>
              </div>
              <ul className="space-y-3 text-sm text-forest">
                {[
                  "Radically transparent — child sees everything",
                  "Gentle nudges + offline rewards, not punishments",
                  "Wellness, mood & balance — not just minutes",
                  "Co-created Family Constitution, signed by all",
                  "Bloom, the AI coach who validates feelings first",
                ].map((t) => (
                  <li key={t} className="flex items-start gap-3">
                    <span className="w-5 h-5 rounded-full bg-sage flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Check className="w-3 h-3 text-cream" strokeWidth={3} />
                    </span>
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* ============ Benefits — bigger, more delightful ============ */}
      <section className="relative py-24 bg-cream-deep grain overflow-hidden">
        <div className="blob blob-sky" style={{ top: "-50px", left: "10%", width: 300, height: 300 }} />
        <div className="blob blob-gold" style={{ bottom: "0", right: "5%", width: 280, height: 280 }} />

        <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
          <div className="max-w-2xl mb-16">
            <div className="label-tiny mb-4">What you'll feel</div>
            <h2 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] mb-6">
              Six tiny <em className="text-sage">miracles</em> a family can expect.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {[
              { emoji: "🌅", title: "Calmer mornings", copy: "No more screen tug-of-war before school. The Constitution handles it." },
              { emoji: "🧘", title: "Less guilt", copy: "Stop being the bad cop. Bloom carries the gentle reminders." },
              { emoji: "🚴", title: "Real-world wins", copy: "Cycle, cook, sketch, call a friend — XP that means something." },
              { emoji: "💬", title: "Open conversations", copy: "Children come to you. They feel safe saying 'I'm tired today.'" },
              { emoji: "🌱", title: "Healthier habits", copy: "Tiny daily quests compound into lifelong balance." },
              { emoji: "💚", title: "Trust rebuilt", copy: "Transparency replaces sneaking. Respect replaces surveillance." },
            ].map((b, i) => (
              <div key={b.title}
                   className="group card-soft p-7 hover:-translate-y-1 transition-all duration-500 fade-up relative overflow-hidden"
                   style={{ animationDelay: `${i * 80}ms` }}
                   data-testid={`benefit-${i}`}>
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 gradient-sage-cream" />
                <div className="relative">
                  <div className="badge-soft mb-5 group-hover:bounce-soft">{b.emoji}</div>
                  <h3 className="font-serif-display text-xl text-forest mb-2 leading-snug">{b.title}</h3>
                  <p className="text-sm text-moss leading-relaxed">{b.copy}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ Original features ============ */}
      <section className="py-24 sm:py-32 relative">
        <div className="max-w-7xl mx-auto px-6 sm:px-8">
          <div className="max-w-2xl mb-16">
            <div className="label-tiny mb-4">Inside Flourish</div>
            <h2 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl leading-[1.05] mb-6">
              Designed for families,<br /><em className="text-sage">not surveillance.</em>
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: ShieldCheck, title: "Radically transparent",
                copy: "Children see their own dashboard. Bloom always explains why a suggestion was made. No secret tracking." },
              { icon: Wand2, title: "AI quests, real life",
                copy: "Personalised offline missions matched to mood, time and interests. Earn XP for cycling, cooking, reading, calling a friend." },
              { icon: MessageCircleHeart, title: "Bloom, the gentle coach",
                copy: "A warm AI companion — never preachy, never shame. Validates feelings, then offers one tiny next step." },
            ].map((f, i) => (
              <div key={f.title} className="card-soft p-8 fade-up relative group hover:elevated transition-all duration-500"
                   style={{ animationDelay: `${i * 100}ms` }} data-testid={`feature-${i}`}>
                <div className="w-14 h-14 rounded-2xl bg-sage/10 flex items-center justify-center mb-6 group-hover:rotate-3 transition-transform">
                  <f.icon className="w-6 h-6 text-sage" strokeWidth={1.5} />
                </div>
                <h3 className="font-serif-display text-2xl text-forest mb-3 leading-snug">{f.title}</h3>
                <p className="text-moss leading-relaxed text-sm">{f.copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ How it works ============ */}
      <section className="py-24 bg-cream-deep grain relative overflow-hidden">
        <div className="blob blob-sage" style={{ top: "20%", right: "-100px", width: 320, height: 320 }} />

        <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="rounded-[40px] overflow-hidden shadow-xl aspect-[4/5] relative">
              <img src={TEEN_READING} alt="Teen reading outdoors" className="w-full h-full object-cover" />
              <div className="absolute top-6 right-6 note-tag right">
                <div className="label-tiny mb-1">Today's quest</div>
                <div className="font-serif-display text-lg text-forest">Read 30 min outside</div>
                <div className="text-xs text-sage-deep mt-1">+80 XP</div>
              </div>
            </div>
            <div>
              <div className="label-tiny mb-4">How it works</div>
              <h2 className="font-serif-display text-4xl sm:text-5xl leading-[1.05] mb-10">A wellness ritual,<br /><em>not a leash.</em></h2>
              <div className="space-y-8">
                {[
                  ["01", "Co-create your Family Constitution", "Sit down together. Agree on rules. Kids who help create are 3× more likely to follow."],
                  ["02", "Bloom learns the rhythm", "Mood, screen-time, interests. Quests adapt every day to what your child actually needs."],
                  ["03", "Trade screens for stories", "Cycle to the park. Cook with Mum. Sketch the cat. Real XP for real moments."],
                ].map(([num, title, copy]) => (
                  <div key={num} className="flex gap-6" data-testid={`step-${num}`}>
                    <div className="font-serif-display text-3xl text-sage min-w-[60px] relative">
                      {num}
                      <span className="absolute -top-2 -right-2 w-1.5 h-1.5 rounded-full bg-gold sparkle-anim" />
                    </div>
                    <div>
                      <h4 className="font-serif-display text-xl text-forest mb-2">{title}</h4>
                      <p className="text-moss text-sm leading-relaxed">{copy}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============ Image triptych - real life ============ */}
      <section className="py-24 relative overflow-hidden">
        <div className="blob blob-gold" style={{ top: "20%", right: "-100px", width: 280, height: 280, opacity: 0.3 }} />
        <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
            <div className="max-w-2xl">
              <div className="label-tiny mb-3">Real life, rewarded</div>
              <h2 className="font-serif-display text-4xl sm:text-5xl leading-[1.05]">The quests your child<br /> will <em className="text-sage">actually love</em>.</h2>
            </div>
            <p className="text-sm text-moss max-w-sm">
              A few examples — Bloom's AI engine generates hundreds more, tuned to your child's age, mood and the time they have.
            </p>
          </div>

          {/* Featured row — 3 large image cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-6">
            {[
              { img: CHILD_NATURE, title: "🚴 Cycle to the park", xp: "+150 XP", tag: "Family", time: "1 hour" },
              { img: FAMILY_COOKING, title: "🍳 Cook with Mum", xp: "+200 XP", tag: "Together", time: "1 hour" },
              { img: TEEN_READING, title: "📖 Read 30 minutes", xp: "+80 XP", tag: "Solo", time: "30 min" },
            ].map((q) => (
              <div key={q.title} className="relative rounded-[28px] overflow-hidden aspect-[4/5] group" data-testid={`quest-card-${q.tag.toLowerCase()}`}>
                <img src={q.img} alt={q.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, transparent 30%, rgba(44,64,46,0.82) 100%)" }} />
                <div className="absolute top-4 left-4 flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-cream/95 text-xs uppercase tracking-wider text-forest font-medium">{q.tag}</span>
                  <span className="px-3 py-1 rounded-full bg-forest/60 backdrop-blur text-cream text-xs">{q.time}</span>
                </div>
                <div className="absolute bottom-5 left-5 right-5 text-cream">
                  <div className="font-serif-display text-2xl mb-1">{q.title}</div>
                  <div className="text-sm" style={{ color: "#dca750" }}>{q.xp}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Compact mini quests grid - more variety */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
            {[
              { emoji: "🎨", title: "Sketch what you see", xp: 80, tag: "Solo", time: "20 min" },
              { emoji: "📞", title: "Call a friend (real voice!)", xp: 120, tag: "Solo", time: "15 min" },
              { emoji: "🧘", title: "5 mindful breaths", xp: 50, tag: "Solo", time: "5 min" },
              { emoji: "🌱", title: "Plant something", xp: 180, tag: "Family", time: "1 hour" },
              { emoji: "⚽", title: "Kick a ball outside", xp: 120, tag: "Solo", time: "30 min" },
              { emoji: "📝", title: "Write a thank-you note", xp: 90, tag: "Family", time: "15 min" },
              { emoji: "🎲", title: "Board game with family", xp: 200, tag: "Together", time: "1 hour" },
              { emoji: "🐦", title: "Spot 5 birds", xp: 100, tag: "Solo", time: "30 min" },
              { emoji: "🥗", title: "Make a smoothie", xp: 110, tag: "Solo", time: "20 min" },
              { emoji: "📷", title: "Take 3 nature photos", xp: 90, tag: "Solo", time: "30 min" },
              { emoji: "🎵", title: "Learn a new song", xp: 160, tag: "Solo", time: "1 hour" },
              { emoji: "💌", title: "Write to a grandparent", xp: 140, tag: "Family", time: "30 min" },
            ].map((q, i) => (
              <div key={q.title}
                   className="card-soft p-4 fade-up group hover:-translate-y-1 transition-all relative overflow-hidden"
                   style={{ animationDelay: `${i * 40}ms` }}
                   data-testid={`mini-quest-${q.title.replace(/\W/g, "")}`}>
                <div className="absolute -top-3 -right-3 w-16 h-16 rounded-full bg-sage/8 group-hover:bg-sage/15 transition-colors" />
                <div className="text-3xl mb-3 relative">{q.emoji}</div>
                <div className="text-sm font-medium text-forest leading-snug mb-1.5">{q.title}</div>
                <div className="flex items-center gap-2 text-[10px] uppercase tracking-wider text-moss">
                  <span>{q.tag}</span>
                  <span>·</span>
                  <span>{q.time}</span>
                </div>
                <div className="mt-3 pt-3 border-t flex items-center justify-between" style={{ borderColor: "rgba(44,64,46,0.06)" }}>
                  <span className="text-xs text-sage-deep font-semibold">+{q.xp} XP</span>
                  <span className="text-[10px] text-moss">earn</span>
                </div>
              </div>
            ))}
          </div>

          {/* CTA strip */}
          <div className="mt-12 p-6 sm:p-8 rounded-[28px] gradient-sage-cream flex flex-col sm:flex-row items-center gap-6">
            <div className="text-4xl bounce-soft">✨</div>
            <div className="flex-1 text-center sm:text-left">
              <div className="font-serif-display text-xl text-forest mb-1">300+ quests, freshly generated</div>
              <div className="text-sm text-moss">Bloom adapts every quest to your child's mood, free time, interests and risk level — every day.</div>
            </div>
            <Link to="/register" className="btn-primary text-sm whitespace-nowrap">
              Start free <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ============ NEW: Testimonials ============ */}
      <section className="relative py-24 sm:py-32 overflow-hidden">
        <div className="blob blob-sage" style={{ top: "10%", left: "-50px", width: 300, height: 300, opacity: 0.3 }} />

        <div className="max-w-7xl mx-auto px-6 sm:px-8 relative z-10">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="label-tiny mb-4">Voices from real families</div>
            <h2 className="font-serif-display text-4xl sm:text-5xl leading-[1.05]">
              The change happens <em className="text-sage">quietly</em>.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { quote: "For the first time in years, dinner is device-free without a fight. The kids agreed to the rule themselves.",
                name: "Mira K.", role: "Mum of 2, Mumbai", img: AVATARS[2] },
              { quote: "My son told Bloom he was stressed about exams. Bloom suggested a 15-minute walk. He came back smiling.",
                name: "Rajiv S.", role: "Father of 1, Bangalore", img: AVATARS[0] },
              { quote: "I'm 14. I actually like that I get to see my own dashboard. It's not my parents spying — it's just mine.",
                name: "Ananya, 14", role: "Daughter, Delhi", img: AVATARS[1] },
            ].map((t, i) => (
              <div key={t.name} className="card-soft p-7 fade-up relative" style={{ animationDelay: `${i * 100}ms` }} data-testid={`testimonial-${t.name.replace(/\W/g, "")}`}>
                <Quote className="w-8 h-8 text-sage/40 absolute top-5 right-5" />
                <p className="font-serif-display text-lg text-forest leading-relaxed mb-6 italic">"{t.quote}"</p>
                <div className="flex items-center gap-3">
                  <img src={t.img} alt={t.name} className="w-11 h-11 rounded-full object-cover" />
                  <div>
                    <div className="text-sm text-forest font-medium">{t.name}</div>
                    <div className="text-xs text-moss">{t.role}</div>
                  </div>
                </div>
                <div className="flex gap-1 mt-4">
                  {[1,2,3,4,5].map(s => <Star key={s} className="w-3 h-3 text-gold fill-gold" />)}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ Final CTA ============ */}
      <section className="relative py-24 sm:py-32 overflow-hidden">
        <div className="blob blob-gold" style={{ top: "20%", right: "10%", width: 280, height: 280 }} />
        <div className="blob blob-sage" style={{ bottom: "10%", left: "10%", width: 280, height: 280 }} />

        <div className="max-w-5xl mx-auto px-6 sm:px-8 relative z-10">
          <div className="card-soft elevated p-10 sm:p-16 text-center relative overflow-hidden gradient-shift"
               style={{ background: "linear-gradient(135deg, #fcfbf8 0%, #f5f1e8 50%, #ede6d4 100%)" }}>
            <div className="absolute top-6 left-6 sparkle-anim">
              <Sparkles className="w-5 h-5 text-gold" />
            </div>
            <div className="absolute bottom-6 right-6 sparkle-anim" style={{ animationDelay: "1s" }}>
              <Sparkles className="w-4 h-4 text-sage" />
            </div>

            <Sun className="w-12 h-12 text-gold mx-auto mb-6 bounce-soft" strokeWidth={1.5} />
            <h2 className="font-serif-display text-4xl sm:text-5xl lg:text-6xl mb-6 leading-[1.05]">
              Begin a calmer chapter,<br /> <em className="text-sage">together.</em>
            </h2>
            <p className="text-moss max-w-xl mx-auto mb-10 text-lg">
              Free for one child, forever. Premium unlocks unlimited children, unlimited Bloom, and the full Quest Engine.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/register" className="btn-primary" data-testid="cta-register">
                Create your family <ArrowRight className="w-4 h-4" />
              </Link>
              <Link to="/pricing" className="btn-secondary" data-testid="cta-pricing">
                See pricing
              </Link>
            </div>
            <p className="text-xs text-moss mt-6 tracking-wider uppercase">No credit card · Cancel anytime</p>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

function FloatingLeaf({ className, style }) {
  return (
    <svg className={className} style={style} viewBox="0 0 24 24" fill="currentColor">
      <path d="M17 8C8 10 5.9 16.17 3.82 21.34l1.89.66.95-2.3c.48.17.98.3 1.34.3 5.5 0 9-4 9-9V8z" />
    </svg>
  );
}
