import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, auth } from "@/lib/api";
import Nav from "@/components/Nav";
import { Sparkles, ChevronRight, Crown, Wand2 } from "lucide-react";

const MOODS = ["Happy", "Tired", "Stressed", "Excited"];
const TIMES = ["15 min", "30 min", "1 hour", "2+ hours"];
const TYPES = ["solo", "family", "community"];

export default function QuestEngine() {
  const nav = useNavigate();
  const [children, setChildren] = useState([]);
  const [activeChild, setActiveChild] = useState(null);
  const [ctx, setCtx] = useState({ mood: "Happy", time: "30 min", type: "solo" });
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const u = auth.user();

  useEffect(() => {
    if (!auth.isLoggedIn()) { nav("/login"); return; }
    let mounted = true;
    api.get("/children").then(({ data }) => {
      if (!mounted) return;
      setChildren(data.children || []);
      if (data.children?.[0]) setActiveChild(data.children[0].id);
    }).catch((e) => console.error("children load failed", e));
    return () => { mounted = false; };
  }, [nav]);

  const child = children.find((c) => c.id === activeChild);

  const generate = async () => {
    if (!activeChild) return;
    setLoading(true); setErr(""); setResults([]);
    try {
      const { data } = await api.post("/quests/generate", {
        child_id: activeChild,
        mood: ctx.mood,
        time_available: ctx.time,
        quest_type: ctx.type,
      });
      setResults(data.quests || []);
    } catch (e) {
      setErr(e?.response?.data?.detail || "Could not generate quests");
    } finally { setLoading(false); }
  };

  const accept = async (id) => {
    try {
      await api.post(`/quests/${id}/accept`);
      setResults(results.map(q => q.id === id ? {...q, status: "active"} : q));
    } catch (e) { console.error("accept quest failed", e); }
  };

  return (
    <div className="min-h-screen bg-cream">
      <Nav />
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-8 sm:py-12">
        <div className="mb-10 max-w-3xl">
          <div className="label-tiny mb-3">Quest Engine</div>
          <h1 className="font-serif-display text-4xl sm:text-5xl text-forest leading-[1.05] mb-4">
            AI-crafted missions for <em className="text-sage">real life</em>.
          </h1>
          <p className="text-moss leading-relaxed">
            Bloom designs quests tuned to your child's mood, free time and interests. Each one is offline-first and rewarding.
          </p>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Left: Children selector */}
          <div className="col-span-12 lg:col-span-4 space-y-3">
            <div className="label-tiny mb-1">Select a child</div>
            {children.map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveChild(c.id)}
                data-testid={`engine-child-${c.id}`}
                className={`w-full text-left card-soft p-5 flex items-center gap-4 transition-all ${
                  activeChild === c.id ? "ring-2 ring-sage" : "hover:-translate-y-0.5"
                }`}
              >
                <span className="w-11 h-11 rounded-full flex items-center justify-center text-cream font-medium"
                      style={{ background: c.avatar_color || "#5d7a5f" }}>{c.name[0]}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-forest font-medium">{c.name}, {c.age}</div>
                  <div className="text-xs text-moss truncate">
                    {(c.interests || []).slice(0,3).join(" · ") || "No interests yet"}
                  </div>
                </div>
                <span className="text-[10px] px-2 py-1 rounded-full uppercase tracking-wider font-semibold"
                      style={{ background: c.risk_level === "high" ? "rgba(194,111,96,0.15)" : c.risk_level === "moderate" ? "rgba(220,167,80,0.15)" : "rgba(93,122,95,0.15)",
                               color: c.risk_level === "high" ? "#a04030" : c.risk_level === "moderate" ? "#a06d20" : "#4a634c" }}>
                  {c.risk_level}
                </span>
              </button>
            ))}
            {children.length === 0 && (
              <div className="card-soft p-6 text-center text-sm text-moss">Add a child from the Dashboard first.</div>
            )}
          </div>

          {/* Right: Context + generate + results */}
          <div className="col-span-12 lg:col-span-8 space-y-6">
            <div className="card-soft p-6 sm:p-8" data-testid="engine-context">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-serif-display text-2xl text-forest">Current context</h3>
                <Sparkles className="w-5 h-5 text-sage" />
              </div>

              {child && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-7 text-sm">
                  <Pill label="Profile" value={`${child.name}, ${child.age}`} />
                  <Pill label="Risk" value={child.risk_level} />
                  <Pill label="Mood" value={ctx.mood} />
                  <Pill label="Time" value={ctx.time} />
                </div>
              )}

              <Picker label="Mood" options={MOODS} value={ctx.mood} onChange={(v) => setCtx({...ctx, mood: v})} testKey="mood" />
              <Picker label="Time available" options={TIMES} value={ctx.time} onChange={(v) => setCtx({...ctx, time: v})} testKey="time" />
              <Picker label="Quest type" options={TYPES} value={ctx.type} onChange={(v) => setCtx({...ctx, type: v})} cap testKey="type" />

              <button onClick={generate} disabled={!activeChild || loading} className="btn-primary w-full mt-6" data-testid="generate-quests">
                {loading ? "Bloom is thinking…" : <><Wand2 className="w-4 h-4" /> Generate quests {child ? `for ${child.name}` : ""}</>}
              </button>
              {u?.tier !== "premium" && (
                <p className="text-xs text-moss mt-3 text-center">Free plan: 3 generations / day. <a href="/pricing" className="text-sage-deep underline">Upgrade for unlimited</a></p>
              )}
              {err && <div className="mt-3 text-sm text-terra bg-terra/10 p-3 rounded-2xl" data-testid="engine-error">{err}</div>}
            </div>

            <div>
              <div className="label-tiny mb-3">Generated quests</div>
              {!loading && results.length === 0 && (
                <div className="card-soft p-12 text-center" data-testid="engine-empty">
                  <div className="text-4xl mb-3">🗺️</div>
                  <p className="text-forest font-serif-display text-xl mb-1">No quests yet</p>
                  <p className="text-sm text-moss">Pick a child and hit generate.</p>
                </div>
              )}
              {loading && (
                <div className="space-y-3">
                  {[1,2,3].map(i => <div key={i} className="card-soft p-5 shimmer h-24" />)}
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {results.map((q, i) => (
                  <div key={q.id} className="card-soft p-5 fade-up" style={{animationDelay: `${i*80}ms`}} data-testid={`generated-quest-${i}`}>
                    <div className="flex items-start justify-between mb-3">
                      <div className="text-4xl">{q.emoji}</div>
                      <div className="text-sm font-semibold text-sage-deep">+{q.xp} XP</div>
                    </div>
                    <h4 className="font-serif-display text-lg text-forest leading-snug mb-1.5">{q.title}</h4>
                    <p className="text-sm text-moss leading-relaxed mb-4 min-h-[36px]">{q.description}</p>
                    {q.status === "active" ? (
                      <button className="btn-secondary w-full text-sm" disabled data-testid={`quest-accepted-${i}`}>
                        <Crown className="w-3.5 h-3.5" /> Accepted
                      </button>
                    ) : (
                      <button onClick={() => accept(q.id)} className="btn-primary w-full text-sm" data-testid={`accept-quest-${i}`}>
                        Send to {child?.name} <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Pill({ label, value }) {
  return (
    <div className="bg-cream-deep rounded-2xl px-3.5 py-2.5">
      <div className="text-[10px] uppercase tracking-wider text-moss">{label}</div>
      <div className="text-sm text-forest font-medium capitalize">{value}</div>
    </div>
  );
}

function Picker({ label, options, value, onChange, cap, testKey }) {
  return (
    <div className="mb-5">
      <div className="label-tiny mb-2">{label}</div>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o}
            data-testid={`picker-${testKey}-${o}`}
            onClick={() => onChange(o)}
            className={`px-4 py-2 rounded-full text-sm transition-all ${
              value === o ? "bg-forest text-cream" : "bg-cream-deep text-forest hover:bg-cream"
            } ${cap ? "capitalize" : ""}`}
          >
            {o}
          </button>
        ))}
      </div>
    </div>
  );
}
