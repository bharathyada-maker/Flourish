import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { api, auth } from "@/lib/api";
import Nav from "@/components/Nav";
import { Plus, Gift, Trash2, Sparkles, Check, X, ArrowRight, Edit2 } from "lucide-react";

const CATEGORIES = ["treat", "experience", "item", "screen_time", "family"];
const SUGGESTED_EMOJIS = ["🎁", "📱", "🎬", "🌙", "📚", "🍕", "💸", "🎮", "🎟️", "🛍️", "🎨", "⚽"];

export default function Marketplace() {
  const nav = useNavigate();
  const [rewards, setRewards] = useState([]);
  const [pending, setPending] = useState([]);
  const [fulfilled, setFulfilled] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ title: "", emoji: "🎁", description: "", xp_cost: 200, category: "treat" });

  const load = useCallback(async () => {
    try {
      const [r, p, f] = await Promise.all([
        api.get("/rewards"),
        api.get("/redemptions?status_filter=pending"),
        api.get("/redemptions?status_filter=fulfilled"),
      ]);
      setRewards(r.data.rewards || []);
      setPending(p.data.redemptions || []);
      setFulfilled(f.data.redemptions || []);
    } catch (e) { console.error("marketplace load failed", e); }
  }, []);

  useEffect(() => {
    if (!auth.isLoggedIn()) { nav("/login"); return; }
    load();
  }, [nav, load]);

  const openAdd = () => {
    setEditing(null);
    setForm({ title: "", emoji: "🎁", description: "", xp_cost: 200, category: "treat" });
    setShowAdd(true);
  };
  const openEdit = (r) => {
    setEditing(r);
    setForm({ title: r.title, emoji: r.emoji, description: r.description || "", xp_cost: r.xp_cost, category: r.category });
    setShowAdd(true);
  };

  const save = async (e) => {
    e.preventDefault();
    try {
      const payload = { ...form, xp_cost: Number(form.xp_cost) };
      if (editing) {
        await api.patch(`/rewards/${editing.id}`, payload);
      } else {
        await api.post("/rewards", payload);
      }
      setShowAdd(false); setEditing(null);
      load();
    } catch (e) { console.error("save reward failed", e); }
  };

  const remove = async (id) => {
    if (!window.confirm("Remove this reward?")) return;
    try { await api.delete(`/rewards/${id}`); load(); }
    catch (e) { console.error("delete reward failed", e); }
  };

  const fulfill = async (id) => {
    try { await api.post(`/redemptions/${id}/fulfill`); load(); }
    catch (e) { console.error("fulfill failed", e); }
  };
  const refund = async (id) => {
    if (!window.confirm("Refund the XP back to the child?")) return;
    try { await api.post(`/redemptions/${id}/refund`); load(); }
    catch (e) { console.error("refund failed", e); }
  };

  return (
    <div className="min-h-screen bg-cream">
      <Nav />
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-8 sm:py-12">
        <div className="mb-10 max-w-3xl">
          <div className="label-tiny mb-3">Rewards Marketplace</div>
          <h1 className="font-serif-display text-4xl sm:text-5xl text-forest leading-[1.05] mb-4">
            Trade XP for <em className="text-sage">real treats</em>.
          </h1>
          <p className="text-moss leading-relaxed">
            Decide what your child can earn. They redeem with XP. You fulfill. Every reward becomes a small ritual of trust.
          </p>
        </div>

        {/* Pending redemptions banner */}
        {pending.length > 0 && (
          <div className="card-soft p-5 mb-8 gradient-sage-cream" data-testid="pending-redemptions">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-sage" />
                <div className="label-tiny">Pending — please fulfill</div>
              </div>
              <span className="text-sm text-forest">{pending.length} waiting</span>
            </div>
            <div className="space-y-3">
              {pending.map((r) => (
                <div key={r.id} className="bg-surface/80 rounded-2xl p-4 flex items-center gap-4" data-testid={`pending-${r.id}`}>
                  <span className="text-3xl">{r.reward_emoji}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-forest">{r.reward_title}</div>
                    <div className="text-xs text-moss">
                      {r.child_name} · {r.xp_cost} XP · {new Date(r.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <button onClick={() => fulfill(r.id)} className="btn-primary text-sm" data-testid={`fulfill-${r.id}`}>
                    <Check className="w-4 h-4" /> Fulfilled
                  </button>
                  <button onClick={() => refund(r.id)} className="btn-ghost text-sm text-terra" data-testid={`refund-${r.id}`}>
                    <X className="w-4 h-4" /> Refund XP
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Rewards grid */}
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-serif-display text-2xl text-forest">Your rewards catalog</h2>
          <button onClick={openAdd} className="btn-primary text-sm" data-testid="add-reward-btn">
            <Plus className="w-4 h-4" /> Add reward
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {rewards.length === 0 && (
            <div className="col-span-full card-soft p-12 text-center">
              <Gift className="w-8 h-8 text-sage mx-auto mb-3" />
              <p className="font-serif-display text-xl text-forest mb-1">Empty catalog</p>
              <p className="text-sm text-moss mb-5">Add your first reward — something your child would actually love.</p>
              <button onClick={openAdd} className="btn-primary text-sm">
                <Plus className="w-4 h-4" /> Add your first reward
              </button>
            </div>
          )}
          {rewards.map((r, i) => (
            <div key={r.id} className="card-soft p-6 fade-up hover:-translate-y-0.5 transition-all relative" style={{ animationDelay: `${i * 60}ms` }} data-testid={`reward-card-${r.id}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="badge-soft">{r.emoji}</div>
                <div className="text-right">
                  <div className="font-serif-display text-2xl text-sage-deep">{r.xp_cost}</div>
                  <div className="text-[10px] text-moss uppercase tracking-wider">XP</div>
                </div>
              </div>
              <div className="font-serif-display text-lg text-forest leading-snug mb-2">{r.title}</div>
              <p className="text-sm text-moss leading-relaxed mb-4 min-h-[40px]">{r.description}</p>
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-wider text-moss px-2 py-1 rounded-full bg-cream-deep">{r.category}</span>
                <div className="flex gap-1">
                  <button onClick={() => openEdit(r)} className="btn-ghost !p-2" data-testid={`edit-reward-${r.id}`}>
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => remove(r.id)} className="btn-ghost !p-2 text-terra" data-testid={`delete-reward-${r.id}`}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Fulfilled history */}
        {fulfilled.length > 0 && (
          <div className="mt-12">
            <div className="label-tiny mb-3">Fulfilled — your trust diary</div>
            <div className="card-soft p-5">
              <div className="space-y-3 text-sm">
                {fulfilled.slice(0, 8).map((r) => (
                  <div key={r.id} className="flex items-center gap-3 pb-3 border-b last:border-0" style={{ borderColor: "rgba(44,64,46,0.06)" }}>
                    <span className="text-xl">{r.reward_emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-forest truncate">{r.reward_title}</div>
                      <div className="text-[11px] text-moss">{r.child_name} · {r.xp_cost} XP</div>
                    </div>
                    <span className="text-[11px] text-moss">{new Date(r.fulfilled_at || r.created_at).toLocaleDateString()}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-forest/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-surface rounded-3xl w-full max-w-md p-7 fade-up" data-testid="reward-modal">
            <div className="label-tiny mb-2">{editing ? "Edit reward" : "New reward"}</div>
            <h3 className="font-serif-display text-3xl text-forest mb-6">
              {editing ? "Refine the magic" : "Add a treat"}
            </h3>
            <form onSubmit={save} className="space-y-4">
              <div>
                <label className="label-tiny block mb-2">Emoji</label>
                <div className="flex flex-wrap gap-2">
                  {SUGGESTED_EMOJIS.map((e) => (
                    <button type="button" key={e} onClick={() => setForm({ ...form, emoji: e })}
                            className={`w-10 h-10 rounded-2xl text-xl ${form.emoji === e ? "bg-sage" : "bg-cream-deep hover:bg-cream"}`}>
                      {e}
                    </button>
                  ))}
                  <input value={form.emoji} maxLength={3} onChange={(e) => setForm({ ...form, emoji: e.target.value })}
                         className="w-16 h-10 rounded-2xl bg-cream-deep text-center text-lg" placeholder="🎁" />
                </div>
              </div>
              <div>
                <label className="label-tiny block mb-2">Title</label>
                <input className="input-soft" value={form.title}
                       onChange={(e) => setForm({ ...form, title: e.target.value })}
                       placeholder="e.g. Movie night, your pick" required data-testid="reward-title-input" />
              </div>
              <div>
                <label className="label-tiny block mb-2">Description</label>
                <textarea className="input-soft" rows={2} value={form.description}
                          onChange={(e) => setForm({ ...form, description: e.target.value })}
                          placeholder="Add a sweet detail your child will love" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label-tiny block mb-2">XP cost</label>
                  <input type="number" min={10} step={10} className="input-soft" value={form.xp_cost}
                         onChange={(e) => setForm({ ...form, xp_cost: e.target.value })} required data-testid="reward-xp-input" />
                </div>
                <div>
                  <label className="label-tiny block mb-2">Category</label>
                  <select className="input-soft" value={form.category}
                          onChange={(e) => setForm({ ...form, category: e.target.value })}>
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c.replace(/_/g, " ")}</option>)}
                  </select>
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowAdd(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" className="btn-primary flex-1" data-testid="save-reward">
                  {editing ? "Save" : "Add"} <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
