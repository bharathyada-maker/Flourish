import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { api, auth } from "@/lib/api";
import Nav from "@/components/Nav";
import { Check, Plus, Trash2, Sparkles, Users, MessageCircle, Heart } from "lucide-react";

export default function Family() {
  const nav = useNavigate();
  const [rules, setRules] = useState([]);
  const [children, setChildren] = useState([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newRule, setNewRule] = useState({ text: "", parties: "Parent, Child" });

  const refresh = useCallback(async () => {
    try {
      const [r, c] = await Promise.all([api.get("/constitution"), api.get("/children")]);
      setRules(r.data.rules || []);
      setChildren(c.data.children || []);
    } catch (e) { console.error("family load failed", e); }
  }, []);

  useEffect(() => {
    if (!auth.isLoggedIn()) { nav("/login"); return; }
    refresh();
  }, [nav, refresh]);

  const toggleAgree = async (rule_id, party) => {
    try {
      const { data } = await api.post("/constitution/agree", { rule_id, party });
      setRules(rules.map((r) => (r.id === rule_id ? data.rule : r)));
    } catch (e) { console.error("toggle agree failed", e); }
  };

  const addRule = async (e) => {
    e.preventDefault();
    try {
      await api.post("/constitution", {
        text: newRule.text,
        parties: newRule.parties.split(",").map((s) => s.trim()).filter(Boolean),
      });
      setShowAdd(false);
      setNewRule({ text: "", parties: "Parent, Child" });
      refresh();
    } catch (e) { console.error("add rule failed", e); }
  };

  const remove = async (id) => {
    if (!window.confirm("Remove this rule?")) return;
    try {
      await api.delete(`/constitution/${id}`);
      refresh();
    } catch (e) { console.error("delete rule failed", e); }
  };

  const totalAgreements = rules.reduce((acc, r) => acc + Object.values(r.agreements || {}).filter(Boolean).length, 0);
  const totalSlots = rules.reduce((acc, r) => acc + (r.parties?.length || 0), 0);
  const harmony = totalSlots ? Math.round((totalAgreements / totalSlots) * 100) : 0;

  return (
    <div className="min-h-screen bg-cream">
      <Nav />
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-8 sm:py-12">
        <div className="mb-10 max-w-3xl">
          <div className="label-tiny mb-3">Family Constitution</div>
          <h1 className="font-serif-display text-4xl sm:text-5xl text-forest leading-[1.05] mb-4">
            Co-created rules, <em className="text-sage">honoured together.</em>
          </h1>
          <p className="text-moss leading-relaxed">
            Tap any rule to toggle agreement. Rules children help create are <span className="text-forest font-medium">3× more likely</span> to be followed.
          </p>
        </div>

        <div className="grid grid-cols-12 gap-6 mb-10">
          <div className="col-span-12 sm:col-span-4 card-soft p-6">
            <div className="label-tiny mb-3">Family harmony</div>
            <div className="font-serif-display text-5xl text-forest mb-1">{harmony}</div>
            <div className="text-xs text-sage flex items-center gap-1"><Heart className="w-3 h-3" /> {harmony > 75 ? "Strong" : harmony > 50 ? "Good" : "Growing"}</div>
          </div>
          <div className="col-span-12 sm:col-span-4 card-soft p-6">
            <div className="label-tiny mb-3">Active rules</div>
            <div className="font-serif-display text-5xl text-forest mb-1">{rules.length}</div>
            <div className="text-xs text-moss flex items-center gap-1"><Users className="w-3 h-3" /> Co-signed agreements</div>
          </div>
          <div className="col-span-12 sm:col-span-4 card-soft p-6">
            <div className="label-tiny mb-3">Conversations this week</div>
            <div className="font-serif-display text-5xl text-forest mb-1">12</div>
            <div className="text-xs text-moss flex items-center gap-1"><MessageCircle className="w-3 h-3" /> Bloom helped facilitate</div>
          </div>
        </div>

        <div className="flex items-center justify-between mb-6">
          <h2 className="font-serif-display text-2xl text-forest">Our constitution</h2>
          <button onClick={() => setShowAdd(true)} className="btn-primary text-sm" data-testid="add-rule-btn">
            <Plus className="w-4 h-4" /> Add a rule
          </button>
        </div>

        <div className="space-y-3">
          {rules.length === 0 && (
            <div className="card-soft p-12 text-center">
              <Sparkles className="w-8 h-8 text-sage mx-auto mb-3" />
              <p className="text-forest font-serif-display text-xl mb-1">No rules yet</p>
              <p className="text-sm text-moss">Sit down with your child and co-create your first one.</p>
            </div>
          )}
          {rules.map((r) => {
            const agreedAll = r.parties.every(p => r.agreements?.[p]);
            return (
              <div key={r.id} className="card-soft p-5 sm:p-6" data-testid={`rule-${r.id}`}>
                <div className="flex items-start gap-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${agreedAll ? "bg-sage" : "border-2"}`}
                       style={!agreedAll ? { borderColor: "rgba(44,64,46,0.2)" } : {}}>
                    {agreedAll && <Check className="w-4 h-4 text-cream" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-forest leading-snug mb-3">{r.text}</div>
                    <div className="flex flex-wrap gap-2">
                      {r.parties.map((p) => {
                        const agreed = r.agreements?.[p];
                        return (
                          <button
                            key={p}
                            data-testid={`rule-${r.id}-party-${p}`}
                            onClick={() => toggleAgree(r.id, p)}
                            className={`text-xs px-3 py-1.5 rounded-full transition-all ${
                              agreed ? "bg-sage text-cream" : "bg-cream-deep text-moss hover:bg-cream"
                            }`}
                          >
                            {agreed ? "✓ " : ""}{p}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                  <button onClick={() => remove(r.id)} className="btn-ghost text-terra" data-testid={`delete-rule-${r.id}`}>
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bloom suggestion card */}
        <div className="card-soft p-6 sm:p-8 mt-10" style={{ background: "linear-gradient(135deg, rgba(93,122,95,0.08), rgba(220,167,80,0.05))" }}>
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-sage flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-4 h-4 text-cream" />
            </div>
            <div>
              <div className="label-tiny mb-1">Bloom suggests</div>
              <p className="text-forest leading-relaxed text-sm sm:text-base">
                {children[0] ? `${children[0].name} followed ${Math.max(1, Math.min(5, totalAgreements))} of your agreements this week — a meaningful improvement. Acknowledge this tonight at dinner.`
                            : "Once you add a child and rules, Bloom will surface gentle insights here."}
              </p>
            </div>
          </div>
        </div>
      </div>

      {showAdd && (
        <div className="fixed inset-0 bg-forest/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="bg-surface rounded-3xl w-full max-w-md p-7 fade-up" data-testid="add-rule-modal">
            <div className="label-tiny mb-2">New agreement</div>
            <h3 className="font-serif-display text-3xl text-forest mb-6">Add a rule</h3>
            <form onSubmit={addRule} className="space-y-4">
              <div>
                <label className="label-tiny block mb-2">The rule (in your own words)</label>
                <textarea className="input-soft" rows={3} value={newRule.text}
                          onChange={(e) => setNewRule({...newRule, text: e.target.value})}
                          placeholder="e.g. No screens after 9:30 PM on school nights"
                          required data-testid="rule-text-input" />
              </div>
              <div>
                <label className="label-tiny block mb-2">Who needs to agree?</label>
                <input className="input-soft" value={newRule.parties}
                       onChange={(e) => setNewRule({...newRule, parties: e.target.value})}
                       placeholder="Parent, Arjun" data-testid="rule-parties-input" />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="button" onClick={() => setShowAdd(false)} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" className="btn-primary flex-1" data-testid="submit-rule">Add rule</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
