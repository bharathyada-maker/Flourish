import { useEffect, useState, useRef, useCallback } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { api, auth } from "@/lib/api";
import { Check, ArrowRight, Loader2 } from "lucide-react";

const MAX_ATTEMPTS = 8;

export default function BillingSuccess() {
  const [params] = useSearchParams();
  const session_id = params.get("session_id");
  const [status, setStatus] = useState(session_id ? "checking" : "error");
  const [attempts, setAttempts] = useState(0);
  const cancelledRef = useRef(false);

  const poll = useCallback(async (n) => {
    if (cancelledRef.current || n >= MAX_ATTEMPTS) {
      if (n >= MAX_ATTEMPTS) setStatus("error");
      return;
    }
    try {
      const { data } = await api.get(`/checkout/status/${session_id}`);
      setAttempts(n + 1);
      if (data.payment_status === "paid") {
        setStatus("paid");
        const u = auth.user();
        if (u) { u.tier = "premium"; u.subscription_status = "active"; auth.setUser(u); }
        return;
      }
      if (data.status === "expired") { setStatus("expired"); return; }
      setTimeout(() => poll(n + 1), 2000);
    } catch (e) {
      console.error("billing poll failed", e);
      setStatus("error");
    }
  }, [session_id]);

  useEffect(() => {
    if (!session_id) return;
    cancelledRef.current = false;
    poll(0);
    return () => { cancelledRef.current = true; };
  }, [session_id, poll]);

  return (
    <div className="min-h-screen bg-cream flex items-center justify-center px-5">
      <div className="card-soft p-10 sm:p-14 max-w-lg w-full text-center">
        {status === "checking" && (
          <>
            <Loader2 className="w-10 h-10 text-sage mx-auto mb-6 animate-spin" />
            <h1 className="font-serif-display text-3xl text-forest mb-3">Confirming your subscription…</h1>
            <p className="text-moss text-sm">Just a moment while we verify with Stripe. ({attempts}/{MAX_ATTEMPTS})</p>
          </>
        )}
        {status === "paid" && (
          <>
            <div className="w-14 h-14 rounded-full bg-sage mx-auto mb-6 flex items-center justify-center">
              <Check className="w-6 h-6 text-cream" strokeWidth={2.5} />
            </div>
            <h1 className="font-serif-display text-4xl text-forest mb-3">Welcome to Flourish.</h1>
            <p className="text-moss mb-8 leading-relaxed">
              Your premium garden is open. Unlimited Bloom, unlimited quests, unlimited little wins.
            </p>
            <Link to="/dashboard" className="btn-primary" data-testid="billing-go-dashboard">
              Go to dashboard <ArrowRight className="w-4 h-4" />
            </Link>
          </>
        )}
        {status === "expired" && (
          <>
            <h1 className="font-serif-display text-3xl text-forest mb-3">Session expired</h1>
            <p className="text-moss mb-8">No worries — try again whenever you're ready.</p>
            <Link to="/pricing" className="btn-primary">Back to pricing</Link>
          </>
        )}
        {status === "error" && (
          <>
            <h1 className="font-serif-display text-3xl text-forest mb-3">Something went sideways</h1>
            <p className="text-moss mb-8">We couldn't verify the payment. If you were charged, please contact us.</p>
            <Link to="/pricing" className="btn-primary">Back to pricing</Link>
          </>
        )}
      </div>
    </div>
  );
}
