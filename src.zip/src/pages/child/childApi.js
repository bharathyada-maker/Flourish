import axios from "axios";
import { API } from "@/lib/api";

export const CHILD_TOKEN = "flourish_child_token";
export const CHILD_PROFILE = "flourish_child";

export const childAxios = axios.create({ baseURL: API });
childAxios.interceptors.request.use((cfg) => {
  const t = localStorage.getItem(CHILD_TOKEN);
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});

export function readChild() {
  try { return JSON.parse(localStorage.getItem(CHILD_PROFILE) || "null"); }
  catch { return null; }
}

export function writeChild(child) {
  localStorage.setItem(CHILD_PROFILE, JSON.stringify(child));
}

export async function childLogout() {
  try { await childAxios.post("/child-portal/logout"); }
  catch (e) { console.error("child logout failed", e); }
  localStorage.removeItem(CHILD_TOKEN);
  localStorage.removeItem(CHILD_PROFILE);
}
