import { useEffect, useState, useCallback } from "react";
import { childAxios, readChild, writeChild, childLogout } from "./childApi";
import { burstConfetti } from "@/lib/confetti";
import ChildLogin from "./ChildLogin";
import HomeTab from "./HomeTab";
import QuestsTab from "./QuestsTab";
import CoachTab from "./CoachTab";
import RewardsTab from "./RewardsTab";
import FamilyTab from "./FamilyTab";
import BottomNav from "./BottomNav";

export default function ChildApp() {
  const [child, setChild] = useState(readChild());
  if (!child) return <ChildLogin onLogin={(c) => setChild(c)} />;
  return <ChildShell child={child} setChild={setChild} onLogout={async () => {
    await childLogout();
    setChild(null);
  }} />;
}

function ChildShell({ child, setChild, onLogout }) {
  const [tab, setTab] = useState("home");
  const [dash, setDash] = useState(null);
  const [quests, setQuests] = useState([]);

  const load = useCallback(async () => {
    try {
      const [d, q] = await Promise.all([
        childAxios.get(`/children/${child.id}/dashboard`),
        childAxios.get(`/children/${child.id}/quests`),
      ]);
      setDash(d.data);
      setQuests(q.data.quests || []);
    } catch (e) { console.error("child load failed", e); }
  }, [child.id]);

  useEffect(() => { load(); }, [tab, load]);

  const completeQuest = async (id) => {
    try {
      const { data } = await childAxios.post(`/quests/${id}/complete`);
      burstConfetti(window.innerWidth / 2, window.innerHeight / 2);
      if (data.total_xp != null) {
        const updated = { ...child, total_xp: data.total_xp, level: data.level, badges: data.badges };
        writeChild(updated);
        setChild(updated);
      }
      load();
    } catch (e) { console.error("complete quest failed", e); }
  };

  return (
    <div className="min-h-screen bg-cream">
      <div className="phone-frame">
        <div className="px-6 pt-7 pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-full flex items-center justify-center text-cream text-sm font-medium" style={{ background: child.avatar_color || "#5d7a5f" }}>{child.name[0]}</span>
              <span className="text-xs text-moss">9:41</span>
            </div>
            <button onClick={onLogout} className="text-[10px] text-moss tracking-widest uppercase" data-testid="child-logout">Sign out</button>
          </div>
        </div>

        <div className="pb-24">
          {tab === "home" && <HomeTab child={child} dash={dash} quests={quests} onComplete={completeQuest} />}
          {tab === "quests" && <QuestsTab quests={quests} onComplete={completeQuest} />}
          {tab === "coach" && <CoachTab child={child} />}
          {tab === "rewards" && <RewardsTab child={child} setChild={setChild} />}
          {tab === "family" && <FamilyTab child={child} />}
        </div>

        <BottomNav tab={tab} setTab={setTab} />
      </div>
    </div>
  );
}
