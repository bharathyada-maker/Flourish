import { useState } from "react";
import { ArrowRight } from "lucide-react";

export default function QuestsTab({ quests, onComplete }) {
  const [filter, setFilter] = useState("active");
  const filtered = quests.filter((q) =>
    filter === "active" ? q.status === "active" || q.status === "suggested" :
    filter === "done" ? q.status === "completed" : true
  );

  return (
    <div className="px-6 pt-3 pb-4">
      <h1 className="font-serif-display text-3xl text-forest leading-tight mb-1">Quests <span className="text-gold text-2xl">✦</span></h1>
      <p className="text-xs text-moss mb-5">Real-world missions, real XP</p>

      <div className="flex gap-2 mb-5">
        {[["active","Active"],["done","Done"],["all","All"]].map(([k,l]) => (
          <button key={k} onClick={() => setFilter(k)}
                  className={`text-xs px-4 py-2 rounded-full transition-all ${filter===k ? "bg-forest text-cream shadow-md" : "bg-cream-deep text-moss"}`}
                  data-testid={`quest-filter-${k}`}>
            {l}
          </button>
        ))}
      </div>

      <div className="space-y-3">
        {filtered.length === 0 && <p className="text-sm text-moss text-center py-8">Nothing here yet.</p>}
        {filtered.map((q, i) => (
          <div key={q.id} className={`card-soft p-4 fade-up ${q.status === "completed" ? "opacity-60" : "hover:-translate-y-0.5 transition-all"}`}
               style={{ animationDelay: `${i*60}ms` }}
               data-testid={`quests-tab-${q.id}`}>
            <div className="flex items-start gap-4">
              <div className="badge-soft flex-shrink-0">{q.emoji}</div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-forest leading-snug">{q.title}</div>
                <div className="text-[11px] text-moss mt-0.5 leading-snug">{q.description}</div>
                <div className="mt-2 flex items-center gap-3 text-[10px] uppercase tracking-wider text-moss">
                  <span>{q.quest_type}</span>
                  <span>•</span>
                  <span className="text-sage-deep font-semibold">+{q.xp} XP</span>
                </div>
              </div>
            </div>
            {q.status !== "completed" && (
              <button onClick={() => onComplete(q.id)} className="btn-primary w-full mt-3 text-sm" data-testid={`tab-complete-${q.id}`}>
                Mark complete <ArrowRight className="w-4 h-4" />
              </button>
            )}
            {q.status === "completed" && (
              <div className="mt-3 flex items-center gap-2 text-xs text-sage-deep">
                <span className="w-5 h-5 rounded-full bg-sage flex items-center justify-center text-cream text-[10px]">✓</span>
                Completed
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
