import { Sparkles, Flame, Award } from "lucide-react";

const fmt = (m) => `${Math.floor(m/60)}h ${m%60}m`;

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return "Late night";
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export default function HomeTab({ child, dash, quests, onComplete }) {
  const active = quests.filter(q => q.status === "active" || q.status === "suggested").slice(0, 3);
  const wellnessPct = dash?.wellness_score || 0;
  const ringR = 32;
  const ringC = 2 * Math.PI * ringR;

  return (
    <div className="px-6 pt-3 pb-4">
      <p className="text-moss text-sm">{greeting()},</p>
      <h1 className="font-serif-display text-4xl text-forest leading-none mb-1">
        Hey {child.name}! <span className="wave inline-block">👋</span>
      </h1>
      <p className="text-xs text-moss mb-5">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</p>

      {dash && (
        <div className="relative rounded-3xl overflow-hidden mb-5 grain gradient-hero-card p-6 shadow-xl">
          <div className="blob blob-gold" style={{ top: "-50px", right: "-50px", width: 180, height: 180, opacity: 0.4 }} />
          <div className="absolute top-5 right-5 sparkle-anim"><Sparkles className="w-4 h-4 text-gold" /></div>

          <div className="relative z-10 flex items-center gap-5">
            <div className="relative w-24 h-24 flex-shrink-0">
              <svg viewBox="0 0 80 80" className="w-24 h-24 ring-progress">
                <circle cx="40" cy="40" r={ringR} stroke="rgba(245,241,232,0.2)" strokeWidth="7" fill="none" />
                <circle cx="40" cy="40" r={ringR} stroke="#dca750" strokeWidth="7" fill="none" strokeLinecap="round"
                        strokeDasharray={ringC}
                        strokeDashoffset={ringC - (wellnessPct/100) * ringC}
                        style={{ transition: "stroke-dashoffset 1.2s ease" }} />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-cream">
                <div className="font-serif-display text-3xl leading-none">{wellnessPct}</div>
                <div className="text-[9px] opacity-80 tracking-widest uppercase mt-0.5">wellness</div>
              </div>
            </div>

            <div className="flex-1 min-w-0">
              <div className="text-[10px] uppercase tracking-[0.18em] text-cream/70 mb-1">Today</div>
              <div className="font-serif-display text-2xl text-cream leading-tight mb-1">{fmt(dash.today_minutes || 0)} <span className="text-cream/50 text-sm">screen time</span></div>
              <div className="text-xs text-cream/80">Goal: {fmt(dash.goal_minutes || 210)}</div>
              <div className="mt-3 h-1.5 bg-cream/15 rounded-full overflow-hidden">
                <div className="h-full bg-gold rounded-full transition-all duration-700"
                     style={{ width: `${Math.min(100, ((dash.today_minutes || 0) / (dash.goal_minutes || 210)) * 100)}%` }} />
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="card-soft p-4 relative overflow-hidden">
          <Flame className="w-4 h-4 text-terra absolute top-3 right-3" />
          <div className="label-tiny mb-1">Streak</div>
          <div className="font-serif-display text-2xl text-forest">{(dash?.completed_quests_week || 0)} days</div>
          <div className="text-[10px] text-sage mt-1">Keep it growing!</div>
        </div>
        <div className="card-soft p-4 relative overflow-hidden">
          <Award className="w-4 h-4 text-gold absolute top-3 right-3" />
          <div className="label-tiny mb-1">Level</div>
          <div className="font-serif-display text-2xl text-forest">{child.level || 1}</div>
          <div className="text-[10px] text-moss mt-1">{(child.total_xp || 0).toLocaleString()} XP</div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-3">
        <div className="label-tiny">Today's quests</div>
        <span className="text-xs text-moss">{active.length} active</span>
      </div>

      <div className="space-y-3">
        {active.length === 0 && (
          <div className="card-soft p-6 text-center">
            <div className="text-3xl mb-2 bounce-soft inline-block">🌿</div>
            <p className="text-sm text-moss">No quests yet — your parent can generate some.</p>
          </div>
        )}
        {active.map((q, i) => (
          <div key={q.id}
               className="card-soft p-4 flex items-center gap-4 hover:-translate-y-0.5 transition-all fade-up"
               style={{ animationDelay: `${i * 80}ms` }}
               data-testid={`home-quest-${q.id}`}>
            <div className="text-3xl flex-shrink-0">{q.emoji}</div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-forest leading-snug">{q.title}</div>
              <div className="text-[11px] text-moss leading-snug mt-0.5">{q.description}</div>
            </div>
            <button onClick={() => onComplete(q.id)}
                    className="flex flex-col items-center justify-center gap-0.5 px-3 py-2 rounded-2xl bg-sage/10 hover:bg-sage hover:text-cream transition-all group"
                    data-testid={`complete-quest-${q.id}`}>
              <span className="text-xs font-semibold text-sage-deep group-hover:text-cream">+{q.xp}</span>
              <span className="text-[9px] text-moss group-hover:text-cream/80 uppercase tracking-wider">XP</span>
            </button>
          </div>
        ))}
      </div>

      <div className="mt-7 rounded-3xl p-5 relative overflow-hidden gradient-rose grain">
        <div className="absolute top-3 right-3 sparkle-anim"><Sparkles className="w-4 h-4 text-cream" /></div>
        <div className="absolute -bottom-2 -right-2 text-6xl opacity-30">🌸</div>
        <div className="flex items-start gap-3 relative z-10">
          <div className="w-10 h-10 rounded-full bg-cream/30 backdrop-blur flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-4 h-4 text-cream" />
          </div>
          <div>
            <div className="label-tiny mb-1" style={{ color: "rgba(252,251,248,0.8)" }}>Bloom says</div>
            <p className="text-sm text-cream leading-relaxed">
              You completed {dash?.completed_quests_week || 0} quest{(dash?.completed_quests_week || 0)===1?"":"s"} this week. Real-world streaks beat any leaderboard. 🌿
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
