import { useEffect, useState, useCallback } from "react";
import { childAxios } from "./childApi";
import { burstConfetti } from "@/lib/confetti";
import { Sparkles, Star, Gift, Loader2 } from "lucide-react";

const ALL_BADGES = ["Explorer", "Reader", "Chef", "Together", "Mindful", "Athlete"];
const BADGE_EMOJI = {
  Explorer: "🚴", Reader: "📚", Chef: "👨‍🍳", Together: "👨‍👩‍👧", Mindful: "🧘", Athlete: "⚽",
};

export default function RewardsTab({ child, setChild }) {
  const [rewards, setRewards] = useState([]);
  const [redemptions, setRedemptions] = useState([]);
  const [redeemingId, setRedeemingId] = useState(null);
  const [feedback, setFeedback] = useState(null);

  const load = useCallback(async () => {
    try {
      const [r, h] = await Promise.all([
        childAxios.get("/child-portal/rewards"),
        childAxios.get("/child-portal/redemptions"),
      ]);
      setRewards(r.data.rewards || []);
      setRedemptions(h.data.redemptions || []);
    } catch (e) { console.error("rewards load failed", e); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const redeem = async (reward) => {
    setRedeemingId(reward.id); setFeedback(null);
    try {
      const { data } = await childAxios.post("/rewards/redeem", { reward_id: reward.id, child_id: child.id });
      burstConfetti(window.innerWidth / 2, window.innerHeight / 2, 48);
      // update local XP
      const newChild = { ...child, total_xp: data.remaining_xp };
      localStorage.setItem("flourish_child", JSON.stringify(newChild));
      setChild(newChild);
      setFeedback({ ok: true, msg: `Redeemed ${reward.emoji} ${reward.title}!` });
      load();
    } catch (e) {
      console.error("redeem failed", e);
      setFeedback({ ok: false, msg: e?.response?.data?.detail || "Could not redeem" });
    } finally { setRedeemingId(null); }
  };

  const xp = child.total_xp || 0;
  const level = Math.max(1, Math.floor(xp / 200) + 1);
  const xpToNext = (level * 200) - xp;
  const pctToNext = ((xp % 200) / 200) * 100;
  const badges = child.badges || [];

  return (
    <div className="px-6 pt-3 pb-4">
      <h1 className="font-serif-display text-3xl text-forest leading-tight mb-1">Rewards <span className="text-gold text-2xl">★</span></h1>
      <p className="text-xs text-moss mb-6">Trade XP for real treats</p>

      {/* Level hero */}
      <div className="rounded-3xl p-6 text-center mb-6 grain relative overflow-hidden gradient-night-garden">
        <div className="blob blob-gold" style={{ top: "-30px", right: "-30px", width: 150, height: 150, opacity: 0.5 }} />
        <div className="blob blob-sage" style={{ bottom: "-50px", left: "-50px", width: 180, height: 180, opacity: 0.4 }} />
        <div className="absolute top-4 left-4 sparkle-anim"><Sparkles className="w-4 h-4 text-gold" /></div>
        <div className="absolute top-8 right-6 sparkle-anim" style={{ animationDelay: "1s" }}><Star className="w-3 h-3 text-cream" /></div>

        <div className="relative z-10 text-cream">
          <div className="text-[10px] uppercase tracking-[0.2em] opacity-70 mb-2">Your XP wallet</div>
          <div className="font-serif-display text-6xl mb-1">{xp.toLocaleString()}</div>
          <div className="text-sm opacity-90 mb-5 flex items-center justify-center gap-2">
            <span className="dot-sparkle" />
            Level {level} · {level < 3 ? "Sprout" : level < 6 ? "Growing" : level < 10 ? "Balance Seeker" : "Flourishing"}
            <span className="dot-sparkle" />
          </div>
          <div className="h-2.5 rounded-full bg-cream/15 overflow-hidden mb-2 relative">
            <div className="h-full bg-gold rounded-full transition-all duration-1000 relative overflow-hidden"
                 style={{ width: `${pctToNext}%` }}>
              <div className="absolute inset-0 shimmer" />
            </div>
          </div>
          <div className="text-[11px] opacity-80">{xpToNext} XP to Level {level + 1}</div>
        </div>
      </div>

      {/* Marketplace */}
      <div className="flex items-center justify-between mb-3">
        <div className="label-tiny flex items-center gap-2"><Gift className="w-3.5 h-3.5" /> Marketplace</div>
        <span className="text-[10px] text-moss">{rewards.length} treats</span>
      </div>

      {feedback && (
        <div className={`mb-3 p-3 rounded-2xl text-sm ${feedback.ok ? "bg-sage/15 text-sage-deep" : "bg-terra/15 text-terra"}`} data-testid="redeem-feedback">
          {feedback.msg}
        </div>
      )}

      <div className="space-y-3 mb-7">
        {rewards.length === 0 && (
          <div className="card-soft p-6 text-center text-sm text-moss">
            No rewards set up yet — ask your parent to add some in the Marketplace.
          </div>
        )}
        {rewards.map((r, i) => {
          const canAfford = xp >= r.xp_cost;
          const busy = redeemingId === r.id;
          return (
            <div key={r.id}
                 className={`card-soft p-4 fade-up ${!canAfford ? "opacity-70" : "hover:-translate-y-0.5"} transition-all`}
                 style={{ animationDelay: `${i * 60}ms` }}
                 data-testid={`marketplace-reward-${r.id}`}>
              <div className="flex items-start gap-4">
                <div className="badge-soft flex-shrink-0">{r.emoji}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-forest leading-snug">{r.title}</div>
                  <div className="text-[11px] text-moss mt-0.5 leading-snug">{r.description}</div>
                  <div className="text-[10px] uppercase tracking-wider text-moss mt-2">{r.category}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-semibold text-sage-deep">{r.xp_cost}</div>
                  <div className="text-[10px] text-moss uppercase tracking-wider">XP</div>
                </div>
              </div>
              <button onClick={() => redeem(r)} disabled={!canAfford || busy}
                      className={`w-full mt-3 text-sm ${canAfford ? "btn-primary" : "btn-secondary opacity-60 cursor-not-allowed"}`}
                      data-testid={`redeem-btn-${r.id}`}>
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> :
                 canAfford ? <>Redeem <Gift className="w-4 h-4" /></> : `Need ${r.xp_cost - xp} more XP`}
              </button>
            </div>
          );
        })}
      </div>

      {/* Redemption history */}
      {redemptions.length > 0 && (
        <>
          <div className="label-tiny mb-3">Your redemptions</div>
          <div className="space-y-2 mb-6">
            {redemptions.slice(0, 6).map((r) => (
              <div key={r.id} className="card-soft p-3 flex items-center gap-3 text-sm">
                <span className="text-2xl">{r.reward_emoji}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-forest leading-snug truncate">{r.reward_title}</div>
                  <div className="text-[10px] text-moss">{r.xp_cost} XP · {new Date(r.created_at).toLocaleDateString()}</div>
                </div>
                <span className={`text-[10px] px-2 py-1 rounded-full uppercase tracking-wider font-semibold ${
                  r.status === "fulfilled" ? "bg-sage/15 text-sage-deep" :
                  r.status === "refunded"  ? "bg-cream-deep text-moss" :
                                             "bg-gold/20 text-[#a06d20]"
                }`}>{r.status}</span>
              </div>
            ))}
          </div>
        </>
      )}

      {/* Badges */}
      <div className="label-tiny mb-3">Badges earned</div>
      <div className="grid grid-cols-3 gap-3 mb-2">
        {ALL_BADGES.map((b, i) => {
          const unlocked = badges.includes(b);
          return (
            <div key={b}
                 className={`card-soft p-4 text-center fade-up relative overflow-hidden ${unlocked ? "" : "opacity-40"}`}
                 style={{ animationDelay: `${i * 60}ms` }}
                 data-testid={`badge-${b}`}>
              {unlocked && <div className="absolute inset-0 shimmer opacity-50" />}
              <div className={`text-3xl mb-2 relative ${unlocked ? "bounce-soft" : ""}`}>{unlocked ? BADGE_EMOJI[b] : "🔒"}</div>
              <div className="text-[11px] text-forest font-medium relative">{b}</div>
              {unlocked && <div className="absolute top-1 right-1 dot-sparkle" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}
