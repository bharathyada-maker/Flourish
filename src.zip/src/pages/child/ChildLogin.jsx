import { useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { API } from "@/lib/api";
import { CHILD_TOKEN, CHILD_PROFILE } from "./childApi";
import { Leaf, Lock, Sparkles, Star } from "lucide-react";

export default function ChildLogin({ onLogin }) {
  const [form, setForm] = useState({ parent_email: "", name: "", pin: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      const { data } = await axios.post(`${API}/child-portal/login`, form);
      localStorage.setItem(CHILD_TOKEN, data.token);
      localStorage.setItem(CHILD_PROFILE, JSON.stringify(data.child));
      onLogin(data.child);
    } catch (e) {
      console.error("child login failed", e);
      setErr(e?.response?.data?.detail || "Try again");
    } finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen bg-cream flex flex-col relative overflow-hidden">
      <div className="blob blob-sage" style={{ top: "10%", left: "-100px", width: 280, height: 280 }} />
      <div className="blob blob-gold" style={{ bottom: "10%", right: "-100px", width: 280, height: 280 }} />

      <div className="phone-frame flex flex-col relative">
        <div className="absolute top-12 right-12 sparkle-anim"><Sparkles className="w-5 h-5 text-gold" /></div>
        <div className="absolute top-32 left-10 sparkle-anim" style={{ animationDelay: "1.5s" }}><Star className="w-4 h-4 text-sage" /></div>

        <div className="p-7 pt-12 flex-1 relative z-10">
          <Link to="/" className="flex items-center gap-2 mb-10">
            <span className="w-9 h-9 rounded-full bg-sage flex items-center justify-center relative">
              <Leaf className="w-4 h-4 text-cream" />
              <span className="absolute inset-0 rounded-full bg-sage pulse-ring" />
            </span>
            <span className="font-serif-display text-2xl text-forest">flourish</span>
          </Link>

          <div className="text-5xl mb-3 bounce-soft inline-block">🌱</div>
          <div className="label-tiny mb-2">Hey there <span className="wave inline-block">👋</span></div>
          <h1 className="font-serif-display text-4xl text-forest leading-tight mb-3">Your garden.</h1>
          <p className="text-moss mb-8 leading-relaxed text-sm">
            Ask your parent for their email, your name, and your PIN.
          </p>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="label-tiny block mb-2">Parent's email</label>
              <input type="email" className="input-soft" value={form.parent_email}
                     onChange={(e) => setForm({...form, parent_email: e.target.value})}
                     placeholder="mum@example.com" required data-testid="child-login-parent-email" />
            </div>
            <div>
              <label className="label-tiny block mb-2">Your name</label>
              <input className="input-soft" value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} required data-testid="child-login-name" />
            </div>
            <div>
              <label className="label-tiny block mb-2">PIN</label>
              <input className="input-soft tracking-[0.5em] text-center" type="password" inputMode="numeric"
                     maxLength={4} value={form.pin}
                     onChange={(e) => setForm({...form, pin: e.target.value.replace(/\D/g, "")})}
                     required data-testid="child-login-pin" />
            </div>
            {err && <div className="text-sm text-terra bg-terra/10 p-3 rounded-2xl" data-testid="child-login-error">{err}</div>}
            <button type="submit" disabled={busy} className="btn-primary w-full" data-testid="child-login-submit">
              <Lock className="w-4 h-4" /> {busy ? "..." : "Open my garden"}
            </button>
          </form>

          <p className="text-xs text-moss mt-8 text-center">
            Parent? <Link to="/login" className="text-sage-deep underline">Sign in here</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
