import { useEffect, useState, useRef } from "react";
import { childAxios } from "./childApi";
import { Sparkles, Send } from "lucide-react";

const MOODS = [["😊","Happy"],["😴","Tired"],["😰","Stressed"],["🤩","Excited"]];
const PROMPTS = ["I feel overwhelmed", "Help me focus", "Suggest a fun quest"];

export default function CoachTab({ child }) {
  const [msgs, setMsgs] = useState([]);
  const [input, setInput] = useState("");
  const [mood, setMood] = useState(null);
  const [sending, setSending] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const scrollRef = useRef(null);

  useEffect(() => {
    childAxios.get(`/coach/history?child_id=${child.id}`)
      .then(({ data }) => setMsgs(data.messages || []))
      .catch((e) => console.error("coach history failed", e));
  }, [child.id]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTo(0, el.scrollHeight);
  }, [msgs]);

  const send = async (text) => {
    const m = text ?? input;
    if (!m.trim()) return;
    setSending(true);
    const myMsg = { role: "user", text: m, mood, created_at: new Date().toISOString(), id: Date.now()+"-u" };
    setMsgs((prev) => [...prev, myMsg]);
    setInput("");
    try {
      const { data } = await childAxios.post("/coach/chat", { child_id: child.id, message: m, mood, session_id: sessionId });
      setSessionId(data.session_id);
      setMsgs((prev) => [...prev, { role: "assistant", text: data.reply, created_at: new Date().toISOString(), id: Date.now()+"-a" }]);
    } catch (e) {
      console.error("coach chat failed", e);
      setMsgs((prev) => [...prev, { role: "assistant", text: "Sorry, I'm having trouble right now. Try again in a sec?", id: Date.now()+"-e" }]);
    } finally { setSending(false); setMood(null); }
  };

  return (
    <div className="flex flex-col" style={{ minHeight: "calc(100vh - 100px)" }}>
      <div className="px-6 pt-3 pb-4 border-b relative overflow-hidden" style={{ borderColor: "rgba(44,64,46,0.06)" }}>
        <div className="flex items-center gap-3 relative z-10">
          <div className="relative">
            <div className="w-12 h-12 rounded-full bg-sage flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-cream" />
            </div>
            <span className="absolute inset-0 rounded-full bg-sage pulse-ring" />
          </div>
          <div className="flex-1">
            <div className="font-serif-display text-xl text-forest leading-tight">Bloom</div>
            <div className="text-xs text-sage flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-sage animate-pulse" />
              Listening · always gentle
            </div>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 px-6 py-5 overflow-y-auto space-y-4 scrollbar-soft" style={{ maxHeight: "50vh" }}>
        {msgs.length === 0 && (
          <div className="text-center pt-2">
            <div className="text-5xl mb-3 bounce-soft inline-block">🌸</div>
            <p className="font-serif-display text-xl text-forest mb-2">Hi {child.name} 🌿</p>
            <p className="text-moss text-sm mb-1">No pressure to chat.</p>
            <p className="text-xs text-moss">Tap a mood, ask anything, or just say hi.</p>
          </div>
        )}
        {msgs.map((m) => (
          <div key={m.id || m.created_at} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"} fade-up`}>
            {m.role === "assistant" && (
              <div className="w-8 h-8 rounded-full bg-sage flex items-center justify-center mr-2 flex-shrink-0">
                <Sparkles className="w-3.5 h-3.5 text-cream" />
              </div>
            )}
            <div className={`max-w-[78%] p-3.5 rounded-2xl text-sm leading-relaxed ${
              m.role === "user" ? "bg-forest text-cream rounded-br-md" : "bg-surface text-forest rounded-bl-md shadow-sm"
            }`} data-testid={`coach-msg-${m.role}`}>
              {m.text}
            </div>
          </div>
        ))}
        {sending && (
          <div className="flex justify-start items-end gap-2">
            <div className="w-8 h-8 rounded-full bg-sage flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-cream" />
            </div>
            <div className="bg-surface p-4 rounded-2xl shadow-sm">
              <div className="flex gap-1">
                <span className="w-2 h-2 rounded-full bg-sage animate-bounce" style={{animationDelay: "0ms"}} />
                <span className="w-2 h-2 rounded-full bg-sage animate-bounce" style={{animationDelay: "150ms"}} />
                <span className="w-2 h-2 rounded-full bg-sage animate-bounce" style={{animationDelay: "300ms"}} />
              </div>
            </div>
          </div>
        )}
      </div>

      {msgs.length === 0 && (
        <div className="px-6 pb-4 space-y-4">
          <div>
            <div className="label-tiny mb-3">How are you feeling?</div>
            <div className="grid grid-cols-4 gap-2">
              {MOODS.map(([e, m]) => (
                <button key={m}
                        onClick={() => { setMood(m); send(`I'm feeling ${m.toLowerCase()}`); }}
                        className="card-soft p-3 text-center hover:-translate-y-1 transition-all"
                        data-testid={`mood-${m}`}>
                  <div className="text-3xl mb-1">{e}</div>
                  <div className="text-[10px] text-moss">{m}</div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="label-tiny mb-2">Or try…</div>
            <div className="flex flex-wrap gap-2">
              {PROMPTS.map((p) => (
                <button key={p} onClick={() => send(p)}
                        className="text-xs px-3 py-1.5 rounded-full bg-cream-deep text-forest hover:bg-sage hover:text-cream transition-all"
                        data-testid={`prompt-${p}`}>
                  {p}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="px-6 pb-6 pt-2 border-t" style={{ borderColor: "rgba(44,64,46,0.06)" }}>
        <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex gap-2 items-center">
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Tell Bloom anything…"
                 className="input-soft flex-1" data-testid="coach-input" />
          <button type="submit" disabled={sending || !input.trim()} className="btn-primary !p-3" data-testid="coach-send">
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
