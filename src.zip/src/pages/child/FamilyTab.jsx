import { Sparkles, Heart } from "lucide-react";

export default function FamilyTab({ child }) {
  return (
    <div className="px-6 pt-3 pb-4">
      <h1 className="font-serif-display text-3xl text-forest leading-tight mb-1">Family <Heart className="inline w-5 h-5 text-terra" /></h1>
      <p className="text-xs text-moss mb-6">Harmony · Our space</p>

      <div className="rounded-3xl p-6 text-center mb-6 relative overflow-hidden grain" style={{ background: "linear-gradient(135deg, #5d7a5f 0%, #4a634c 100%)" }}>
        <div className="blob blob-gold" style={{ top: "-30px", left: "50%", width: 200, height: 200, opacity: 0.3, transform: "translateX(-50%)" }} />
        <div className="absolute top-4 right-4 sparkle-anim"><Sparkles className="w-4 h-4 text-cream" /></div>

        <div className="relative z-10 text-cream">
          <div className="label-tiny mb-2" style={{ color: "rgba(252,251,248,0.75)" }}>Family harmony</div>
          <div className="font-serif-display text-6xl mb-1">82</div>
          <div className="text-xs opacity-90 mb-5">↑ 11 pts this week</div>
          <div className="grid grid-cols-3 gap-3 pt-5 border-t" style={{ borderColor: "rgba(252,251,232,0.15)" }}>
            {[["💬", "Communication", 88], ["🛋️", "Together", 79], ["📱", "Screen", 62]].map(([e, l, v]) => (
              <div key={l}>
                <div className="text-xl mb-0.5">{e}</div>
                <div className="font-serif-display text-2xl">{v}</div>
                <div className="text-[10px] opacity-80 leading-tight">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="rounded-3xl p-5 mb-4 grain relative overflow-hidden gradient-sage-cream">
        <div className="flex gap-3 items-start relative z-10">
          <div className="text-3xl">🌱</div>
          <p className="text-sm text-forest leading-relaxed">
            {child.name}, you followed 4/5 family agreements this week — that's beautiful. Your parent will notice. 💚
          </p>
        </div>
      </div>

      <div className="label-tiny mb-3">Things we agreed</div>
      <div className="space-y-2">
        {[
          { emoji: "🌙", text: "No screens after 9:30 PM on school nights" },
          { emoji: "🍽️", text: "Dinner is device-free for the whole family" },
          { emoji: "📚", text: "Gaming only after homework is complete" },
        ].map((rule, i) => (
          <div key={rule.text}
               className="card-soft p-4 flex items-center gap-3 text-sm text-forest hover:-translate-y-0.5 transition-all fade-up"
               style={{ animationDelay: `${i * 80}ms` }}>
            <span className="text-2xl">{rule.emoji}</span>
            {rule.text}
            <span className="ml-auto w-6 h-6 rounded-full bg-sage flex items-center justify-center flex-shrink-0">
              <span className="text-cream text-[11px]">✓</span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
