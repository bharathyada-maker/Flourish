import { Home, Compass, MessageCircle, Trophy, Users } from "lucide-react";

const ITEMS = [
  { k: "home",    L: Home,           label: "Home" },
  { k: "quests",  L: Compass,        label: "Quests" },
  { k: "coach",   L: MessageCircle,  label: "Coach" },
  { k: "rewards", L: Trophy,         label: "Rewards" },
  { k: "family",  L: Users,          label: "Family" },
];

export default function BottomNav({ tab, setTab }) {
  return (
    <div className="absolute bottom-0 left-0 right-0 bg-surface/90 backdrop-blur-md border-t" style={{ borderColor: "rgba(44,64,46,0.08)" }}>
      <div className="flex items-center justify-around py-2 px-2 pb-3">
        {ITEMS.map(({ k, L, label }) => (
          <button key={k} onClick={() => setTab(k)}
                  className={`flex flex-col items-center gap-1 px-3 py-2 rounded-2xl transition-all relative ${tab === k ? "text-forest" : "text-moss"}`}
                  data-testid={`bottom-nav-${k}`}>
            {tab === k && <span className="absolute -top-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-sage" />}
            <L className="w-5 h-5" strokeWidth={tab === k ? 2.2 : 1.6} />
            <span className="text-[10px] tracking-wider">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
