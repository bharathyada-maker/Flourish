import { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { api, auth } from "@/lib/api";
import Nav from "@/components/Nav";
import { Check, Crown, Sparkles, ArrowRight, Loader2 } from "lucide-react";

export default function Pricing() {
  const nav = useNavigate();
  const [params] = useSearchParams();
  const [loading, setLoading] = useState(null);
  const u = auth.user();

  const start = async (package_id) => {
    if (!auth.isLoggedIn()) { nav("/register"); return; }
    setLoading(package_id);
    try {
      const { data } = await api.post("/checkout/session", {
        package_id,
        origin_url: window.location.origin,
      });
      window.location.href = data.url;
    } catch (e) {
      console.error("checkout failed", e);
      alert(e?.response?.data?.detail || "Checkout failed");
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="min-h-screen bg-cream">
      <Nav />
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-12 sm:py-20">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="label-tiny mb-3">Pricing</div>
          <h1 className="font-serif-display text-5xl sm:text-6xl text-forest leading-[1.05] mb-6">
            One garden, two ways<br />to <em className="text-sage">tend it.</em>
          </h1>
          <p className="text-lg text-moss leading-relaxed">
            Start free, forever. Upgrade when you're ready for the full Flourish — unlimited children, unlimited Bloom, premium quest packs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {/* Free */}
          <Tier
            name="Seedling"
            price="₹0"
            cadence="forever"
            tagline="A gentle start"
            features={[
              "1 child profile",
              "3 AI quest generations / day",
              "10 Bloom messages / day",
              "Family Constitution (up to 5 rules)",
              "Weekly wellness recap",
            ]}
            ctaText={u?.tier === "free" ? "Your current plan" : "Start free"}
            ctaDisabled={u?.tier === "free"}
            onCta={() => nav("/register")}
            testId="tier-free"
          />

          {/* Premium Monthly */}
          <Tier
            highlighted
            name="Flourish"
            price="$9.99"
            cadence="per month"
            tagline="Everything, unlocked"
            features={[
              "Unlimited child profiles",
              "Unlimited Bloom conversations",
              "Unlimited AI quest generations",
              "Premium quest packs (sports, art, mindfulness)",
              "Family Constitution (unlimited rules)",
              "Advanced wellness insights",
              "Priority care from our team",
            ]}
            badge="Most loved"
            ctaText={u?.tier === "premium" ? "Already premium ✦" : "Upgrade monthly"}
            ctaDisabled={u?.tier === "premium" || loading === "premium_monthly"}
            ctaLoading={loading === "premium_monthly"}
            onCta={() => start("premium_monthly")}
            testId="tier-monthly"
          />

          {/* Premium Yearly */}
          <Tier
            name="Bloom"
            price="$89"
            cadence="per year"
            tagline="Save 25%"
            features={[
              "Everything in Flourish, annually",
              "2 months free vs monthly",
              "Founders' badge for your family",
              "Early access to features",
              "Personal onboarding call",
            ]}
            ctaText={u?.tier === "premium" ? "Already premium ✦" : "Upgrade yearly"}
            ctaDisabled={u?.tier === "premium" || loading === "premium_yearly"}
            ctaLoading={loading === "premium_yearly"}
            onCta={() => start("premium_yearly")}
            testId="tier-yearly"
          />
        </div>

        <div className="card-soft mt-16 p-8 sm:p-12 grid md:grid-cols-3 gap-8 items-center">
          <Sparkles className="w-10 h-10 text-sage mx-auto md:mx-0" />
          <div className="md:col-span-2">
            <h3 className="font-serif-display text-2xl text-forest mb-2">Cancel anytime, no questions asked.</h3>
            <p className="text-moss text-sm leading-relaxed">
              All payments processed securely through Stripe. We never store your card details.
              Your family's data stays private — and you can export or delete everything, anytime.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Tier({ name, price, cadence, tagline, features, ctaText, onCta, ctaDisabled, ctaLoading, highlighted, badge, testId }) {
  return (
    <div className={`relative card-soft p-7 flex flex-col ${highlighted ? "ring-2 ring-sage" : ""}`} data-testid={testId}>
      {badge && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-forest text-cream text-[10px] uppercase tracking-[0.2em] font-semibold px-4 py-1.5 rounded-full">
          {badge}
        </div>
      )}
      <div className="label-tiny mb-2">{name}</div>
      <div className="flex items-baseline gap-2 mb-1">
        <div className="font-serif-display text-5xl text-forest">{price}</div>
      </div>
      <div className="text-xs text-moss mb-1">{cadence}</div>
      <div className="text-sm italic text-sage-deep mb-7">{tagline}</div>

      <ul className="space-y-3 mb-8 flex-1">
        {features.map((f) => (
          <li key={f} className="flex items-start gap-2.5 text-sm text-forest">
            <Check className="w-4 h-4 text-sage flex-shrink-0 mt-0.5" />
            <span>{f}</span>
          </li>
        ))}
      </ul>

      <button onClick={onCta} disabled={ctaDisabled || ctaLoading}
              className={`${highlighted ? "btn-primary" : "btn-secondary"} w-full ${ctaDisabled ? "opacity-50 cursor-not-allowed" : ""}`}
              data-testid={`${testId}-cta`}>
        {ctaLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : highlighted ? <Crown className="w-4 h-4" /> : null}
        {ctaText}
        {!ctaDisabled && !ctaLoading && <ArrowRight className="w-4 h-4" />}
      </button>
    </div>
  );
}
