import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { api, auth } from "@/lib/api";
import Nav from "@/components/Nav";
import { ArrowRight, Bell, Crown, Plus, Sparkles, TrendingUp, AlertTriangle, Trophy, Trash2 } from "lucide-react";

const DAY_LABELS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function fmt(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h === 0) return `${m}m`;
  return `${h}h ${m}m`;
}

function Ring({ value, label, color = "#5d7a5f" }) {
  const r = 52;
  const c = 2 * Math.PI * r;
  const pct = Math.min(100, Math.max(0, value));
  const off = c - (pct / 100) * c;
  return (
    <div className="relative w-32 h-32">
      <svg viewBox="0 0 120 120" className="w-32 h-32 ring-progress">
        <circle cx="60" cy="60" r={r} stroke="rgba(44,64,46,0.08)" strokeWidth="10" fill="none" />
        <circle cx="60" cy="60" r={r} stroke={color} strokeWidth="10" fill="none" strokeLinecap="round"
                strokeDasharray={c} strokeDashoffset={off} style={{ transition: "stroke-dashoffset 1s ease" }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="font-serif-display text-3xl text-forest">{value}</div>
        <div className="text-[10px] uppercase tracking-wider text-moss">{label}</div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const nav = useNavigate();
  const u = auth.user();
  const [children, setChildren] = useState([]);
  const [activeChild, setActiveChild] = useState(null);
  const [data, setData] = useState(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newChild, setNewChild] = useState({ name: "", age: 10, interests: "", risk_level: "low", pin: "1234" });
  const [adding, setAdding] = useState(false);
  const [addErr, setAddErr] = useState("");

  const loadDashboard = useCallback(async (id) => {
    try {
      const { data } = await api.get(`/children/${id}/dashboard`);
      setData(data);
    } catch (e) {
      console.error("dashboard load failed", e);
      setData(null);
    }
  }, []);

  const refresh = useCallback(async () => {
    try {
      const { data: r } = await api.get("/children");
      setChildren(r.children || []);
      const first = r.children?.[0];
      if (first) {
        setActiveChild(first.id);
        loadDashboard(first.id);
      }
    } catch (e) {
      console.error("children load failed", e);
    }
  }, [loadDashboard]);

  useEffect(() => {
    if (!auth.isLoggedIn()) { nav("/login"); return; }
    refresh();
  }, [nav, refresh]);

  const switchChild = (id) => {
    setActiveChild(id);
    setData(null);
    loadDashboard(id);
  };

  const addChild = async (e) => {
    e.preventDefault();
    setAdding(true);
    setAddErr("");
    try {
      const payload = {
        name: newChild.name,
        age: Number(newChild.age),
        interests: newChild.interests.split(",").map((s) => s.trim()).filter(Boolean),
        risk_level: newChild.risk_level,
        pin: newChild.pin || "1234",
      };
      const { data } = await api.post("/children", payload);
      setShowAdd(false);
      setNewChild({ name: "", age: 10, interests: "", risk_level: "low", pin: "1234" });
      await refresh();
      switchChild(data.child.id);
    } catch (e) {
      setAddErr(e?.response?.data?.detail || "Could not add child");
    } finally {
      setAdding(false);
    }
  };

  const removeChild = async (id) => {
    if (!window.confirm("Remove this child profile? All their data will be deleted.")) return;
    try {
      await api.delete(`/children/${id}`);
      await refresh();
    } catch (e) { console.error("delete child failed", e); }
  };

  if (!children.length) {
    return (
      <div className="min-h-screen bg-cream">
        <Nav />
        <div className="max-w-3xl mx-auto px-6 py-20 text-center">
          <Sparkles className="w-10 h-10 text-sage mx-auto mb-6" />
          <h1 className="font-serif-display text-4xl text-forest mb-4">Welcome to Flourish.</h1>
          <p className="text-moss mb-8">Let's add your first child to begin.</p>
          <button onClick={() => setShowAdd(true)} className="btn-primary" data-testid="empty-add-child">
            <Plus className="w-4 h-4" /> Add a child
          </button>
        </div>
        {showAdd && <AddChildModal {...{ newChild, setNewChild, addChild, addErr, adding, onClose: () => setShowAdd(false) }} />}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cream">
      <Nav />

      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-8 sm:py-12">
        {/* Children switcher */}
        <div className="flex flex-wrap items-center gap-3 mb-8">
          {children.map((c) => (
            <button
              key={c.id}
              onClick={() => switchChild(c.id)}
              data-testid={`switch-child-${c.id}`}
              className={`group flex items-center gap-2.5 pl-1.5 pr-4 py-1.5 rounded-full transition-all ${
                activeChild === c.id ? "bg-forest text-cream" : "bg-surface text-forest hover:bg-cream-deep"
              }`}
              style={{ border: "1px solid rgba(44,64,46,0.1)" }}
            >
              <span className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium"
                    style={{ background: c.avatar_color || "#5d7a5f", color: "#f5f1e8" }}>
                {c.name[0]}
              </span>
              <span className="text-sm">{c.name}</span>
              <span className="text-[10px] opacity-60">{c.age}</span>
            </button>
          ))}
          <button onClick={() => setShowAdd(true)} className="btn-ghost text-sm" data-testid="add-child-btn">
            <Plus className="w-4 h-4" /> Add child
          </button>
        </div>

        {data && (
          <>
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
              <div>
                <div className="label-tiny mb-2">{data.child.name}'s wellness today</div>
                <h1 className="font-serif-display text-4xl sm:text-5xl text-forest leading-tight">
                  Saturday · Week {Math.ceil(new Date().getDate() / 7) + 20} · <em className="text-sage">{data.child.age} years old</em>
                </h1>
              </div>
              <div className="flex gap-2">
                <button onClick={() => removeChild(data.child.id)} className="btn-ghost text-sm text-terra" data-testid="remove-child">
                  <Trash2 className="w-4 h-4" /> Remove
                </button>
                {u?.tier !== "premium" && (
                  <button onClick={() => nav("/pricing")} className="btn-primary" data-testid="upgrade-btn">
                    <Crown className="w-4 h-4" /> Upgrade
                  </button>
                )}
              </div>
            </div>

            {/* BENTO grid */}
            <div className="grid grid-cols-12 gap-5 sm:gap-6">
              {/* Top stat cards */}
              <StatCard className="col-span-12 sm:col-span-6 lg:col-span-3" label="Screen time today" value={fmt(data.today_minutes)} sub={`Goal: ${fmt(data.goal_minutes)}`} accent={data.today_minutes > data.goal_minutes ? "#c26f60" : "#5d7a5f"} testId="stat-screentime" />
              <StatCard className="col-span-12 sm:col-span-6 lg:col-span-3" label="Wellness score" value={data.wellness_score} sub={data.wellness_score >= 70 ? "Healthy range" : data.wellness_score >= 50 ? "Moderate risk" : "Needs attention"} accent="#5d7a5f" testId="stat-wellness" />
              <StatCard className="col-span-12 sm:col-span-6 lg:col-span-3" label="Quests completed" value={data.completed_quests_week} sub="This week" accent="#dca750" testId="stat-quests" />
              <StatCard className="col-span-12 sm:col-span-6 lg:col-span-3" label="Family harmony" value={82} sub="↑ Improving" accent="#5d7a5f" testId="stat-harmony" />

              {/* Week chart */}
              <div className="col-span-12 lg:col-span-8 card-soft p-6 sm:p-8" data-testid="week-chart">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="label-tiny mb-1">Screen time — this week</div>
                    <h3 className="font-serif-display text-2xl text-forest">A rhythm in minutes</h3>
                  </div>
                  <TrendingUp className="w-5 h-5 text-sage" />
                </div>
                <div className="flex items-end gap-2 sm:gap-3 h-44">
                  {data.week_minutes.map((d, i) => {
                    const max = Math.max(...data.week_minutes.map(x => x.minutes), data.goal_minutes);
                    const h = (d.minutes / max) * 100;
                    const over = d.minutes > data.goal_minutes;
                    return (
                      <div key={d.date} className="flex-1 flex flex-col items-center gap-2">
                        <div className="text-[10px] text-moss">{fmt(d.minutes)}</div>
                        <div className="w-full rounded-t-2xl transition-all" style={{
                          height: `${Math.max(8, h)}%`,
                          background: over ? "#c26f60" : "#5d7a5f",
                          opacity: 0.85,
                        }} />
                        <div className="text-[10px] text-moss uppercase">{DAY_LABELS[i]}</div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-6 flex items-center gap-4 text-xs text-moss">
                  <span className="flex items-center gap-2"><span className="w-3 h-3 rounded-full bg-sage" /> Within goal</span>
                  <span className="flex items-center gap-2"><span className="w-3 h-3 rounded-full" style={{ background: "#c26f60" }} /> Over goal</span>
                </div>
              </div>

              {/* Addiction risk card */}
              <div className="col-span-12 lg:col-span-4 card-soft p-6 sm:p-8" data-testid="risk-card">
                <div className="flex items-center justify-between mb-6">
                  <div className="label-tiny">Addiction risk score</div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider"
                        style={{ background: "rgba(220,167,80,0.15)", color: "#a06d20" }}>
                    {data.addiction_risk < 40 ? "Low" : data.addiction_risk < 65 ? "Moderate" : "High"}
                  </span>
                </div>
                <div className="flex items-center gap-6 mb-7">
                  <Ring value={data.addiction_risk} label="of 100" color={data.addiction_risk < 40 ? "#5d7a5f" : data.addiction_risk < 65 ? "#dca750" : "#c26f60"} />
                  <div className="text-xs text-moss leading-relaxed">
                    A composite of screen patterns, mood signals, and offline balance — not a label, just a gentle compass.
                  </div>
                </div>
                <div className="space-y-3">
                  {Object.entries(data.risk_breakdown).map(([k, v]) => (
                    <div key={k}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-forest capitalize">{k.replace(/_/g, " ")}</span>
                        <span className="text-moss">{v}</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-cream-deep overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${v}%`, background: v < 50 ? "#5d7a5f" : v < 70 ? "#dca750" : "#c26f60" }} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Alerts feed */}
              <div className="col-span-12 lg:col-span-7 card-soft p-6 sm:p-8" data-testid="alerts-feed">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="label-tiny mb-1">AI alerts & interventions</div>
                    <h3 className="font-serif-display text-2xl text-forest">Bloom's gentle nudges</h3>
                  </div>
                  <Bell className="w-5 h-5 text-sage" />
                </div>
                <div className="space-y-4">
                  {data.alerts.length === 0 && <p className="text-sm text-moss">No alerts yet — your child's rhythm is balanced today. 🌿</p>}
                  {data.alerts.map((a, i) => (
                    <div key={a.id || i} className="flex gap-4 items-start pb-4 border-b last:border-0" style={{ borderColor: "rgba(44,64,46,0.06)" }}>
                      <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
                           style={{ background: a.type === "intervention" ? "rgba(194,111,96,0.12)" : a.type === "quest_complete" ? "rgba(93,122,95,0.12)" : "rgba(220,167,80,0.12)" }}>
                        {a.type === "intervention" ? <AlertTriangle className="w-4 h-4 text-terra" /> :
                         a.type === "quest_complete" ? <Trophy className="w-4 h-4 text-sage" /> :
                         <Sparkles className="w-4 h-4 text-gold" />}
                      </div>
                      <div className="flex-1">
                        <div className="text-sm text-forest leading-snug">{a.message}</div>
                        <div className="text-[11px] text-moss mt-1">
                          {new Date(a.created_at).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" })}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active quests */}
              <div className="col-span-12 lg:col-span-5 card-soft p-6 sm:p-8" data-testid="active-quests">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="label-tiny mb-1">Active real-world quests</div>
                    <h3 className="font-serif-display text-2xl text-forest">Today's missions</h3>
                  </div>
                  <button onClick={() => nav("/quests")} className="btn-ghost text-sm">
                    Engine <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="space-y-3">
                  {data.active_quests.length === 0 && <p className="text-sm text-moss">No active quests. Generate some in the Quest Engine.</p>}
                  {data.active_quests.map((q) => (
                    <div key={q.id} className="flex items-center gap-4 p-4 rounded-2xl bg-cream-deep">
                      <div className="text-3xl">{q.emoji}</div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-forest">{q.title}</div>
                        <div className="text-xs text-moss capitalize">{q.quest_type}</div>
                      </div>
                      <div className="text-sm font-semibold text-sage-deep whitespace-nowrap">+{q.xp} XP</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {showAdd && <AddChildModal {...{ newChild, setNewChild, addChild, addErr, adding, onClose: () => setShowAdd(false) }} />}
    </div>
  );
}

function StatCard({ className, label, value, sub, accent, testId }) {
  return (
    <div className={`card-soft p-6 ${className}`} data-testid={testId}>
      <div className="label-tiny mb-3">{label}</div>
      <div className="font-serif-display text-4xl text-forest mb-2">{value}</div>
      <div className="text-xs text-moss flex items-center gap-2">
        <span className="w-2 h-2 rounded-full" style={{ background: accent }} />
        {sub}
      </div>
    </div>
  );
}

function AddChildModal({ newChild, setNewChild, addChild, addErr, adding, onClose }) {
  return (
    <div className="fixed inset-0 bg-forest/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-surface rounded-3xl w-full max-w-md p-7 fade-up" data-testid="add-child-modal">
        <div className="label-tiny mb-2">New profile</div>
        <h3 className="font-serif-display text-3xl text-forest mb-6">Add a child</h3>
        <form onSubmit={addChild} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-1">
              <label className="label-tiny block mb-2">Name</label>
              <input className="input-soft" value={newChild.name} onChange={(e) => setNewChild({...newChild, name: e.target.value})} required data-testid="new-child-name" />
            </div>
            <div className="col-span-1">
              <label className="label-tiny block mb-2">Age</label>
              <input type="number" className="input-soft" value={newChild.age} min={5} max={18} onChange={(e) => setNewChild({...newChild, age: e.target.value})} data-testid="new-child-age" />
            </div>
          </div>
          <div>
            <label className="label-tiny block mb-2">Interests (comma sep)</label>
            <input className="input-soft" value={newChild.interests} placeholder="Gaming, Cricket, Music"
                   onChange={(e) => setNewChild({...newChild, interests: e.target.value})} data-testid="new-child-interests" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label-tiny block mb-2">Risk level</label>
              <select className="input-soft" value={newChild.risk_level} onChange={(e) => setNewChild({...newChild, risk_level: e.target.value})} data-testid="new-child-risk">
                <option value="low">Low</option><option value="moderate">Moderate</option><option value="high">High</option>
              </select>
            </div>
            <div>
              <label className="label-tiny block mb-2">PIN (4 digits)</label>
              <input className="input-soft" value={newChild.pin} maxLength={4}
                     onChange={(e) => setNewChild({...newChild, pin: e.target.value.replace(/\D/g, "")})}
                     data-testid="new-child-pin" />
            </div>
          </div>
          {addErr && <div className="text-sm text-terra bg-terra/10 rounded-2xl p-3" data-testid="add-child-error">{addErr}</div>}
          <div className="flex gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary flex-1" data-testid="cancel-add-child">Cancel</button>
            <button type="submit" disabled={adding} className="btn-primary flex-1" data-testid="submit-add-child">{adding ? "..." : "Add"}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
