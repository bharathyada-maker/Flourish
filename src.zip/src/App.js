import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Landing from "@/pages/Landing";
import Auth from "@/pages/Auth";
import Dashboard from "@/pages/Dashboard";
import QuestEngine from "@/pages/QuestEngine";
import Family from "@/pages/Family";
import Pricing from "@/pages/Pricing";
import Marketplace from "@/pages/Marketplace";
import ChildApp from "@/pages/child/ChildApp";
import BillingSuccess from "@/pages/BillingSuccess";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Auth mode="login" />} />
        <Route path="/register" element={<Auth mode="register" />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/quests" element={<QuestEngine />} />
        <Route path="/family" element={<Family />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/child" element={<ChildApp />} />
        <Route path="/billing/success" element={<BillingSuccess />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
